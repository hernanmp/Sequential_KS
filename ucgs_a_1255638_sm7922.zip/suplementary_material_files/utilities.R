
### This is supported by the following R packages:

##  R package Matrix:
##  Douglas Bates and Martin Maechler. Matrix: Sparse and Dense Matrix Classes and Methods. 2005. R package version 1.2-2.
##  Available at: http://CRAN.R-project.org/package=Matrix

##  R package glmgen:
##  Taylor Arnold and Veeranjaneyulu Sadhanala and Ryan Tibshirani. glmgen: Fast algorithms for generalized lasso problems. 2014. R package version 0.0.3.
##  Available at: https://github.com/statsmaths/glmgen


## Rpackage genlasso:
## Taylor B. Arnold and Ryan J. Tibshirani. genlasso: Path algorithm for generalized lasso problems. 2014. 
## available at: http://CRAN.R-project.org/package=genlasso

## Rpackage rTensor:
## James Li and Jacob Bien and Martin Wells. rTensor: Tools for tensor analysis and decomposition. 2014. R package version 1.2.
## available at: http://CRAN.R-project.org/package=rTensor




###  This contains functions that consist of single step updates for tensor decompositions algorithms
## with generalized lasso penalties


##  soft thresholding operator
soft_tresholding <- function(Y,c)
{
  y = abs(Y)-c
  ind = which(0 < y)
  z = rep(0,length(Y)) 
  z[ind] <- y[ind]  ## z now contains the max's
  z = sign(Y)*z
  return(z)
}

#//////////////////////////////////////////////////////////////////////////////


## L1 update for a block coordinate penalized tensor decomposition with L1- norm inducing a constraint
L1_update <- function(X,u,v,c3,index){
  
  if(index == 3)
  {   
    lizt <- list('mat1' = u,'mat2' = v)
    
    Y =  ttl(X, lizt, ms = c(1,2))
    Y =  unfold(Y,row_idx=3,col_idx=c(1,2))
    Y = t(Y@data)
  }
  if(index == 1)
  {   
    lizt <- list('mat1' = u,'mat2' = v)
    
    Y =  ttl(X, lizt, ms = c(2,3))
    # Y = unfold(Y,rs = c(2,3),cs=1)
    Y = unfold(Y,row_idx=1,col_idx=c(2,3))
    Y = t(Y@data)
  }
  
  if(index == 2)
  {   
    lizt <- list('mat1' = u,'mat2' = v)
    
    Y =  ttl(X, lizt, ms = c(1,3))
    Y =  unfold(Y,row_idx=2,col_idx=c(1,3))
    Y = t(Y@data)
  }
  
  
  
  aux =  soft_tresholding(Y,0)
  aux = aux/ norm(aux,"F")  
  
  if(sum(abs(aux))<=c3)
  {
    return(aux)
  }
  
  ## computing delta 
  N = length(Y) 
  d = -N
  abs_Y = abs(Y)
  ord_Y = sort(abs_Y)
  y_abs_sum = sum(abs_Y)
  y_squared_sum = Y %*% t(Y)
  B =   y_abs_sum
  
  aux = 2*(-y_abs_sum*c3*c3-B*d)
  aux1 = (N*c3*c3-d^2)
  aux2 = (c3*c3*y_squared_sum -B^2)
  
  # discriminant = 4*(y_abs_sum*c3+B*d)*(y_abs_sum*c3+B*d)-4*(N*c3-d^2)*(c3*y_squared_sum -B^2)
  discriminant = aux*aux-4*aux1*aux2
  if(discriminant>=0 && (aux != 0 || aux1 !=0))
  {
    
    
    #delta = (aux - sqrt(discriminant))/aux1
    
    if(aux1 !=0){    
      delta = (-aux - sqrt(discriminant))/(2*aux1)
    }
    
    if(aux1 ==0  && aux !=0){    
      delta =  -aux2/aux
    }
    
    
    if(0 <= delta[1] && delta[1] <= ord_Y[1])
    {
      temp =  soft_tresholding(Y,delta[1])
      temp = temp/ norm(temp,"F")   
      return(temp) 
    }
    
    if(aux1 !=0){    
      delta = (-aux + sqrt(discriminant))/(2*aux1)
    }
    
    if(0 <= delta[1] && delta[1] < ord_Y[1])
    {
      temp =  soft_tresholding(Y,delta[1])
      temp = temp/ norm(temp,"F")   
      return(temp) 
    }
    
  }
  
  for(i in 1:(length(Y)-1))
  {
    d =  - (N-i)
    #B = -sum(abs_Y[1:i]) + sum(abs_Y[(i+1):(length(Y))])
    
    B =  y_abs_sum - ord_Y[i] #sum(ord_Y[(i+1):(length(Y))])
    #-sum(ord_Y[1:i]) +
    # aux = 2*(y_abs_sum*c3+B*d)
    # aux1 = 2*(N*c3-d^2)
    # aux2 = (c3*y_squared_sum -B^2)
    y_abs_sum = y_abs_sum - ord_Y[i]
    y_squared_sum = y_squared_sum - ord_Y[i]*ord_Y[i]
    
    aux = 2*(-y_abs_sum*c3*c3-B*d)
    aux1 = ((N-i)*c3*c3-d^2)
    aux2 = (c3*c3*y_squared_sum -B^2)
    #       discriminant = 4*(y_abs_sum*c3+B*d)*(y_abs_sum*c3+B*d)-4*(N*c3-d^2)*(c3*y_squared_sum -B^2)
    
    discriminant = aux*aux - 4*aux1*aux2
    
    if(discriminant>=0 && (aux != 0 || aux1 !=0))
    {
      #  aux = 2*(y_abs_sum*c3+B*d)
      # aux1 = 2*(N*c3-d^2)
      
      
      if(aux1 !=0){    
        delta = (-aux - sqrt(discriminant))/(2*aux1)
      }
      
      if(aux1 ==0 && aux !=0){    
        delta =  -aux2/aux
      }
      
      if(aux2 == 0)
      {
        delta = -aux
      }
      if(delta[1] <= ord_Y[i+1] && delta[1] >= ord_Y[i] )
      {
        temp =  soft_tresholding(Y,delta[1])
        temp = temp/ norm(temp,"F")  
        return(temp)     
      }
      
      if(aux1 !=0){ 
        delta = (-aux + sqrt(discriminant))/(2*aux1)
      }
      if(delta[1] <= ord_Y[i+1] && delta[1] >= ord_Y[i] )
      {
        temp =  soft_tresholding(Y,delta[1])
        temp = temp/ norm(temp,"F")  
        return(temp)     
      }
      
    }
    
  }
  
  ##### 
  i =which(abs_Y==ord_Y[length(Y)])  
  temp = rep(0,length(Y))
  temp[i] =  sign(Y[i])*c3 
  return(t(as.matrix(temp)))  
}

#####################################333
#####################################333
#####################################333
#####################################333

## FL update for a block coordinate of Rank-1 penalized tensor decomposition with FL- norm inducing a constraint
## index corresponds to the mode too pudate, 1,2,3  accordingly.
## v is supposed to correspond to a mode lower that v.Forinstance, if index = 2, then it is assumed
#that v corresponds to the first mode and w to the third one
## c3 is the tunning parameter constraining the penalty induced by A
GenLasso_update <-  function(X,v,w,c3,A,index)
{
  if(index ==1)
  {
    lizt <- list('mat1' = v,'mat2' = w)
    
    Y =  ttl(X, lizt, ms = c(2,3))
    #  Y = unfold(Y,rs = c(2,3),cs=1)
    #  Y = Y@data
    Y =  unfold(Y,row_idx=1,col_idx=c(2,3))
    Y = t(Y@data)
  }
  
  if(index ==2)
  {
    lizt <- list('mat1' = v,'mat2' = w)
    
    Y =  ttl(X, lizt, ms = c(1,3))
    # Y = unfold(Y,rs = c(1,3),cs=2)
    #  Y = Y@data
    Y =  unfold(Y,row_idx=2,col_idx=c(1,3))
    Y = t(Y@data)
  }
  if(index ==3)
  {
    lizt <- list('mat1' = v,'mat2' = w)
    
    Y =  ttl(X, lizt, ms = c(1,2))
    #  Y = unfold(Y,rs = c(1,2),cs=3)
    #  Y = Y@data
    Y =  unfold(Y,row_idx=3,col_idx=c(1,2))
    Y = t(Y@data)
    
  } 
  
  out = genlasso(y=as.vector(Y),D=A,maxsteps = 10500)
  
  #out = fusedlasso(y=as.vector(Y),D=A)
  i_optimal =  0
  r_opimal =  0
  
  lambda = out$lambda 
  beta =  out$beta
  
  n = length(lambda)
  
  
  
  max_path = - 10^1234
  
  
  for(i  in 1:(n-1))
  {
    if(out$lambda[i+1] != out$lambda[i])
    { 
      
      min_i = c()
      r = c()
      
      #  temp = beta[,i]-Y
      #  temp2 = sum(temp*temp) 
      #  temp3 = sum(Y*temp)  
      
      #  AA = temp2*(lambda[i]*c3)^2 -temp2^2
      #  B = -temp3*(-2*(lambda[i]*c3)^2 + 2*temp2)
      # D = sum(Y*Y)*(lambda[i]*c3)^2 - (temp3)^2
      
      u_i = out$u[,i]
      u_j = out$u[,i+1]
      v = (u_j-u_i)/(out$lambda[i+1]-out$lambda[i])
      b = (-out$lambda[i]/(out$lambda[i+1]-out$lambda[i]))*(u_j-u_i)+out$u[,i]
      temp = t(as.matrix(t(A) %*% as.vector(v)))
      temp2 = t(as.matrix(t(A) %*% as.vector(b)))
      temp3 = norm(temp,"F")
      temp4 = norm(Y-temp2,"F")
      temp5 = sum((Y-temp2)*temp)
      
      AA = -temp3^4 + c3*c3*temp3^2
      B =  -2*temp5*c3*c3 + 2*(temp3^2)*temp5
      D = c3*c3 *temp4^2 - temp5^2
      
      discriminant = B*B -4*AA*D
      
      if(discriminant >= 0)
      {
        aux =  sqrt(discriminant) 
        
        
        if(AA != 0)
        {
          r1 = (-B+aux)/(2*AA)  
          r2 = (-B-aux)/(2*AA)
        }
        if(AA ==0 && B !=0)
        {
          r1 =  -D/B 
          r2 =  -D/B
        }
        
        if(AA==0 && B==0)
        {
          r1 = 0
          r2 = 0
        }
        
        if( lambda[i+1]<r1&& r1<lambda[i] ) #r1*temp2+temp3<0 &&
        { 
          min_i = c(min_i,norm(Y-t(as.matrix(t(A) %*% (r1*as.vector(v)+as.vector(b)))),"F")+r1*c3) 
          r = c(r,r1) 
        } 
        
        if( lambda[i+1]<r2&& r2<lambda[i]) # r2*temp2+temp3<0  &&
        {
          min_i = c(min_i,norm(Y-t(as.matrix(t(A) %*% (r2*as.vector(v)+as.vector(b)))),"F")+r2*c3)  
          r = c(r,r2)                
        }          
      } 
      
      
      min_i = c(min_i,sqrt(sum(beta[,i]*beta[,i])) +lambda[i]*c3)
      r = c(r,lambda[i])    
      
      #  min_i = c(min_i,sqrt(sum(beta[,i+1]*beta[,i+1])) +lambda[i+1]*c3)
      # r = c(r,lambda[i+1]/lambda[i])
      
      indx = which(min_i == min(min_i))
      
      r =  r[indx]
      min_i = min_i[indx] 
      
      max_prev = max_path
      max_path = max(-min_i,max_path)
      
      if(max_path > max_prev)
      {       
        #   u =  Y*(1-r)+ beta[,i]*r
        #  u =   (u/norm(u,"F"))* sqrt(2)/2   
        i_optimal = i
        r_optimal = r
      }
    }
  }
  
  ############################
  ############################
  ############################
  ########################################################
  ########################################################
  ############################
  ###  other cases
  
  ### lambda_min
  
  i =  n 
  
  min_i = c()
  r = c()
  
  # temp = beta[,i]-Y
  #  temp2 = sum(temp*temp) 
  # temp3 = sum(Y*temp)  
  
  #AA = temp2*(lambda[i]*c3)^2 - temp2^2
  #B = -temp3*(-2*(lambda[i]*c3)^2 + 2*temp2)
  #D = sum(Y*Y)*(lambda[i]*c3)^2 - (temp3)^2
  
  u_i = out$u[,i]
  v = (-u_i)/(-out$lambda[i])
  b = -out$lambda[i]/(-out$lambda[i])*(-u_i)+out$u[,i]
  temp = t(as.matrix(t(A) %*% as.vector(v))) 
  temp2 = t(as.matrix(t(A) %*% as.vector(b)))
  temp3 = norm(temp,"F")
  temp4 = norm(Y-temp2,"F")
  temp5 = sum((Y-temp2)*temp)
  
  AA = -temp3^4 + c3*c3*temp3^2
  B =  -2*temp5*c3*c3 + 2*(temp3^2)*temp5
  D = c3*c3 *temp4^2 - temp5^2
  
  discriminant = B*B -4*AA*D
  
  
  if(discriminant >= 0)
  {
    aux =  sqrt(discriminant) 
    
    if(AA != 0)
    {
      r1 = (-B+aux)/(2*AA)  
      r2 = (-B-aux)/(2*AA)
    }
    if(AA ==0 && B !=0)
    {
      r1 =  -D/B 
      r2 =  -D/B
    }
    
    if(AA==0 && B==0)
    {
      r1 = 0
      r2 = 0
    }
    
    if(0 <r1&& r1<lambda[i] ) #r1*temp2+temp3<0 &&
    { 
      min_i = c(min_i,norm(Y-t(as.matrix(t(A) %*% (r1*as.vector(v)+as.vector(b)))),"F")+r1*c3) 
      r = c(r,r1) 
    } 
    
    if( 0<r2&& r2<lambda[i] ) #r1*temp2+temp3<0 &&
    { 
      min_i = c(min_i,norm(Y-t(as.matrix(t(A) %*% (r2*as.vector(v)+as.vector(b)))),"F")+r2*c3) 
      r = c(r,r2) 
    }         
  } 
  
  
  min_i = c(min_i,sqrt(sum(beta[,i]*beta[,i])) +lambda[i]*c3)
  r = c(r,lambda[i])    
  
  min_i = c(min_i,sqrt(sum(Y*Y)))
  r = c(r,0)
  
  indx = which(min_i == min(min_i))
  
  r =  r[indx]
  min_i = min_i[indx] 
  
  max_prev = max_path
  max_path = max(-min_i,max_path)
  
  if(max_path > max_prev)
  {       
    #  u =  Y*(1-r)+ beta[,i]*r
    # u =   u/norm(u,"F")* sqrt(2)/2    
    i_optimal = i
    r_optimal = r
  }
  
  ############################
  ############################
  ############################
  ########################################################
  ########################################################
  ############################
  
  
  #  u =  Y*(1-r_optimal)+ beta[,i_optimal]*r_optimal
  if(i_optimal < n)
  { 
    i = i_optimal
    u_i = out$u[,i]
    u_j = out$u[,i+1]
    v = (u_j-u_i)/(out$lambda[i+1]-out$lambda[i])
    b = -out$lambda[i]/(out$lambda[i+1]-out$lambda[i])*(u_j-u_i)+out$u[,i]
  }
  if(i_optimal ==n) 
  {
    i = i_optimal
    u_i = out$u[,i]
    v = (-u_i)/(-out$lambda[i])
    b = -out$lambda[i]/(-out$lambda[i])*(-u_i)+out$u[,i]
  }
  
  u =Y-t(as.matrix(t(A) %*% (r_optimal*as.vector(v)+as.vector(b))))
  u =   (u/norm(u,"F"))     
  
  if(-norm(Y,"F")>max_path)
  {
    u =  (Y/norm(Y,"F"))  
  }
  
  
  return(u)
  
}

###############################################################
###############################################################
###############################################################
###############################################################

inits <- function(k)
{
  return( t(as.matrix(rnorm(k,0,1))))
}
###############################################################
###############################################################
###############################################################
###############################################################


distance <- function(x,y)
{
  return(sqrt(sum((x-y)*(x-y))))
}

###############################################################
###############################################################
###############################################################
###############################################################

### # Rank-1 PTD
## input tensor Z
##  L1 penalty on vector u, first mode. constrained penalty with posible parameters in the grid c1
##  A is matrix for generalized lasso penalty on vector v, the second mode. Unconstrained penalty, tunning parameter chosen adaptively
##  B is matrix for generalized lasso penalty on vector w, the third mode. Unconstrained penalty, tunning parameter chosen adaptively
## Niter is the maximum number of iterations for block coordinate descent. 
## kv is the trendfiltering order of A
## kw is the trendfiltering order of B
PTD_L1AB_unconstrained <- function(Z,A,B,c1,c2,c3,Niter = 10,  kv,kw ) 
{
  
  u = inits(dim(Z)[1])
  v = inits(dim(Z)[2])
  w = inits(dim(Z)[3])
  
  for(j in 1:10)
  {
    lizt <- list('mat2' = v,'mat3' =w)
    u =   ttl(Z, lizt, ms = c(2,3)) 
    u = t(as.matrix(u@data))
    u =  u/norm(u,"F")
    
    lizt <- list('mat2' = u,'mat3' =w)
    v =   ttl(Z, lizt, ms = c(1,3)) 
    v = t(as.matrix(v@data))
    v =  v/norm(v,"F")
    
    lizt <- list('mat2' = u,'mat3' =v)
    w =   ttl(Z, lizt, ms = c(1,2)) 
    w = t(as.matrix(w@data))
    w =  w/norm(w,"F")
  }
  
  u_prev = u; v_prev = v; w_prev =w;
  
  lizt <- list('mat1' =u_prev,'mat2' = v_prev,'mat3' =w_prev)
  fprev =  ttl(Z, lizt, ms = c(1,2,3)) 
  
  fprev = fprev@data 
  
  # cl<-makeCluster(4)
  #registerDoSNOW(cl)
  for( iter in 1:Niter)
  {
    lizt <- list('mat2' = u,'mat3' =v)
    w =   ttl(Z, lizt, ms = c(1,2)) 
    
    ##########################################################33
    
    response = as.vector(w@data)
    
    df = Inf
    test_length = floor(length(response)* .2)
    x = seq( 0,1,length= length(response))
    
    indexes = sort(sample.int( length(response),test_length,replace=FALSE))
    test_x = x[indexes]
    training_x  =  x[setdiff(1:length(response),indexes)]
    
    test_response = response[ indexes ]
    training_response = response[ setdiff(1:length(response),indexes) ]
    
    
    closest_index = apply( as.matrix(test_x),1, function(psi) {
      which.min( abs(psi - training_x) )
    } )       
    
    
    for(s in 1:length(c3))
    {
      sol =   glmgen::trendfilter(training_response, k = kw , family = "gaussian", method = "admm", lambda = c3[s])
      sol =  as.vector(predict(sol, lambda = c3[s]))
      
      df_s = sum((test_response - sol[closest_index] )^2)
      
      if(df_s < df)
      {
        w = sol
        df = df_s
        c3_star = c3[s]
      }#close if
      
    }
    #     
    sol =   glmgen::trendfilter(response, k = kw , family = "gaussian", method = "admm", lambda = c3_star)
    w =  as.vector(predict(sol, lambda = c3_star))
    
    w = t(as.matrix(w))
    w = w/norm(w,"F")
    
    
    ##########################################################33
    
    response =     lizt <- list('mat2' = v,'mat3' =w)
    response  =   ttl(Z, lizt, ms = c(2,3)) 
    response = as.vector(response@data)
    response
    df = Inf
    
    test_length = floor(length(response)* .2)
    x = seq( 0,1,length= length(response))
    
    indexes = sort(sample.int( length(response),test_length,replace=FALSE))
    test_x = x[indexes]
    training_x  =  x[setdiff(1:length(response),indexes)]
    
    test_response = response[ indexes ]
    training_response = response[ setdiff(1:length(response),indexes) ]
    
    
    closest_index = apply( as.matrix(test_x),1, function(psi) {
      which.min( abs(psi - training_x) )
    } )
    
    
    
    for(s in 1:length(c1))
    {
      sol =  as.vector(L1_update(Z,v,w,c1[s],1))
      
      df_s = sum((sol  - response)^2) + 2*(sigma^2)*sum(which(abs(as.vector(sol)   )>10^-7 ))
      
      if(df_s < df)
      {
        u = matrix(sol,1,length(sol))
        df = df_s
        c1_star = c1[s]        
      }#close if
      
    }
    
    
    ##########################################################
    
    # u =  as.matrix(L1_update(Z,v,w,c1,1)) 
    #  if(length(which(u!=0))==0)
    # {   iter = 42000; break}
    
    
    
    lizt <- list('mat2' = u,'mat3' =w)
    v =   ttl(Z, lizt, ms = c(1,3)) 
    
    
    ##########################################################33
    
    response = as.vector(v@data)
    df = Inf
    
    test_length = floor(length(response)* .2)
    x = seq( 0,1,length= length(response))
    
    indexes = sort(sample.int( length(response),test_length,replace=FALSE))
    test_x = x[indexes]
    training_x  =  x[setdiff(1:length(response),indexes)]
    
    test_response = response[ indexes ]
    training_response = response[ setdiff(1:length(response),indexes) ]
    
    
    closest_index = apply( as.matrix(test_x),1, function(psi) {
      which.min( abs(psi - training_x) )
    } )
    
    
    for(s in 1:length(c2))
    {
      sol =    glmgen::trendfilter( training_response, k = kv , family = "gaussian", method = "admm", lambda = c2[s])
      sol =  as.vector(predict(sol, lambda = c2[s]))
      
      #df_s = sum((sol  - response)^2) + 2*(sigma^2)*sum(which(abs( as.vector(A %*%sol) )>10^-5 ))
      
      
      df_s = sum((test_response - sol[closest_index] )^2)
      
      if(df_s < df)
      {
        v = sol
        df = df_s
        c2_star = c2[s]
      }#close if
      
    }
    sol =    glmgen::trendfilter(response, k = kw , family = "gaussian", method = "admm", lambda = c2_star)
    v =  as.vector(predict(sol, lambda = c2_star))
    
    ##########################################################
    
    #  v = trendfilter( as.vector(v@data), k = 0 , family = "gaussian", method = "admm", lambda = c2)
    #  v = predict(v, lambda = c2)
    v = t(as.matrix(v))
    v = v/norm(v,"F")
    
    # v =   as.matrix(Untrendfilterned_GenLasso_update(Z,u,w,c2,A,2)) 
    #  if(length(which(v!=0))==0)
    #  {   iter = 42000; break}
    
    
    lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
    f =  ttl(Z, lizt, ms = c(1,2,3)) 
    f = f@data 
    
    aux = abs((f-fprev)/(fprev+ 0.0001))
    
    
    if( aux< 0.000001)
    { break}
    
    
    fprev = f
    u_prev = u; v_prev = v; w_prev =w;
  }
  
  
  lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
  d = ttl(Z, lizt, ms = c(1,2,3))  
  
  
  return(list(iter = iter, u = u, v= v, w=w,d=d,c1 = c1_star,c2 = c2_star,c3 =c3_star)) 
}

###############################################################
###############################################################
###############################################################
###############################################################

### # Rank-1 PTD
## input tensor Z
## no constrain on u, first mode,
##  A is matrix for generalized lasso penalty on vector v, the second mode. Unconstrained penalty, tunning parameter chosen adaptively
## no constrain on vector w, the third mode. Constrained penalty
## Niter is the maximum number of iterations for block coordinate descent. 

PTD_A <- function(Z,A,c1,Niter) 
{
  
  # initials
  u = inits(dim(Z)[1])
  v = inits(dim(Z)[2])
  w = inits(dim(Z)[3])
  

  
  u_prev = u; v_prev = v; w_prev =w;
  
  lizt <- list('mat1' =u_prev,'mat2' = v_prev,'mat3' =w_prev)
  fprev =  ttl(Z, lizt, ms = c(1,2,3)) 
  
  fprev = fprev@data 
  
  # cl<-makeCluster(4)
  #registerDoSNOW(cl)
  for( iter in 1:Niter)
  {
    #  updating w
    lizt <- list('mat1' = u,'mat2' = v)
    
    Y =  ttl(Z, lizt, ms = c(1,2))
    Y = unfold(Y,rs = c(1,2),cs=3)
    Y = Y@data
    
    w = (Y/norm(Y,"F"))     
    
    if(length(which(w!=0))==0)
    {   iter = 42000; break}
    #################  
    #### updatiing u 
    
    lizt <- list('mat1' = v,'mat2' = w)
    
    Y =  ttl(Z, lizt, ms = c(2,3))
    Y = unfold(Y,rs = c(2,3),cs=1)
    Y = Y@data
    
    u = (Y/norm(Y,"F"))   
    
    if(length(which(u!=0))==0)
    {   iter = 42000; break}
    ###############################################################################       
    #  updating v
    v =  as.matrix(GenLasso_update(Z,u,w,c1,A,2))

    
    if(length(which(v!=0))==0)
    {   iter = 42000; break}
    

    lizt <- list('mat1' =u,'mat2' = as.matrix(v),'mat3' =w)
    f =  ttl(Z, lizt, ms = c(1,2,3)) 
    f = f@data 
    
    aux = abs((f-fprev)/(fprev+ 0.0001))
    
    
    if( aux< 0.00001)
    { break}
    
    
    fprev = f
    u_prev = u; v_prev = v; w_prev =w;
  }

  lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
  d = ttl(Z, lizt, ms = c(1,2,3))  
  
  
  return(list(iter = iter, u = u, v= v, w=w,d=d)) 
}


#######################################################################3
#########################################################################
#######################################################################3
#########################################################################
#######################################################################3
#########################################################################

### Crosss validation function for the previous function

cv_PTD_A <- function(Z,Z_training,Z_locations,A,c1,indicator)
{
  
  MSE = Inf
  
  for (i in 1:length(c1))
  {
    
    PTD = PTD_A(Z_training,A,c1[i],5) 
  
    iter = PTD$iter           
    
    if(iter < 42000)### making sure that the decompisition has produce unit vectors
    {
      u = PTD$u
      v = PTD$v
      w = PTD$w 
      
      
      lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
      g = ttl(Z_training, lizt, ms = c(1,2,3))
      
      
      lizt <- list('mat1' =t(u),'mat2' = t(v),'mat3' =t(w))
      
      aux = Z_locations*ttl(g, lizt, ms = c(1,2,3))
      X_aux2 = Z_locations * Z
      aux =  fnorm(aux-X_aux2)
      
      if(  MSE > aux) 
      {
        MSE =  aux
        i_star =i; 
      }
    }        
  }
  
  return(list(i = i_star,PMSE=MSE))
}

###############################################################
###############################################################
###############################################################
###############################################################


### # Rank-1 PTD
## input tensor Z
##  L1 penalty on vector u, first mode. constrained penalty with tunning parameter c1
##  A is matrix for generalized lasso penalty on vector v, the second mode. Constraioned penalty, tunning parameter 
##  B is matrix for generalized lasso penalty on vector w, the third mode. Constrained penalty, tunning parameter
## Niter is the maximum number of iterations for block coordinate descent. 

PTD_constrained <- function(Z,A,B,u,v,w, c1,c2,c3,Niter) 
{
  
  
  u =  t(as.matrix(u))
  v =  t(as.matrix(v))
  w =  t(as.matrix(w))
  
  
  u_prev = u; v_prev = v; w_prev =w;
  
  lizt <- list('mat1' =u_prev,'mat2' = v_prev,'mat3' =w_prev)
  fprev =  ttl(Z, lizt, ms = c(1,2,3)) 
  
  fprev = fprev@data 
  
  
  for( iter in 1:Niter)
  {
    
    w = GenLasso_update(Z,u,v,c3,B,3)
    
    if(length(which(w!=0))==0)
    {   iter = 42000; break}
    
    u =  as.matrix(L1_update(Z,v,w,c1,1)) 
    if(length(which(u!=0))==0)
    {   iter = 42000; break}
    
    v =  GenLasso_update(Z,u,w,c2,A,2)
    if(length(which(v!=0))==0)
    {   iter = 42000; break}
    
    lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
    f =  ttl(Z, lizt, ms = c(1,2,3)) 
    f = f@data 
    
    aux = abs((f-fprev)/(fprev+ 0.0001))
    
    
    if( aux< 0.001)
    { break}
    
    
    fprev = f
    u_prev = u; v_prev = v; w_prev =w;
  }
  
  lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
  d = ttl(Z, lizt, ms = c(1,2,3))  
  
  
  return(list(iter = iter, u = u, v= v, w=w,d=d)) 
}

######
##########################################################################################
##################################################################################################################
##########################################################################################
##################################################################################################################
##########################################################################################
##################################################################################################################


### # Rank-1 PTD
## Crossvalidation for rank-1 PTD with unconstrained penalties
## input tensor Z
## Z_training is the tensor with deleted entries for crossvalidation
## Z_locations is the tensor with a one in the deleted entries and zero otherwise
##  L1 penalty on vector u, first mode. constrained penalty with tunning parameters in the grid c1
##  A is matrix for generalized lasso penalty on vector v, the second mode. Unconstraioned penalty, tunning parameters in grid c2 
##  B is matrix for generalized lasso penalty on vector w, the third mode. Unconstrained penalty, tunning parameters in grid c3
## Niter is the maximum number of iterations for block coordinate descent. 
## the tunning parameters in c2 and c3 are chosen adaptively

cv_PTD_L1AB_unconstrained <- function(Z,Z_training,Z_locations,A,B,c1,c2,c3,kv,kw)
{
  
  MSE = Inf
  
  for (i in 1:length(c1))
  {
    for(j in 1:length(c2))
    {
      for(k in 1:length(c3))
      {
        
        PTD = PTD_L1AB_unconstrained_2(Z_training,A,B,c1[i],c2[j],c3[k],5,kv,kw)   
        
        iter = PTD$iter           
        
        if(iter < 42000)
        {
          u = PTD$u
          v = PTD$v
          w = PTD$w 
          
          
          lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
          g = ttl(Z_training, lizt, ms = c(1,2,3))
          
          
          lizt <- list('mat1' =t(u),'mat2' = t(v),'mat3' =t(w))
          
          aux = Z_locations*ttl(g, lizt, ms = c(1,2,3))
          X_aux2 = Z_locations * Z
          aux =  fnorm(aux-X_aux2)
          
          if(  MSE > aux) 
          {
            MSE =  aux
            i_star =i; j_star =j;k_star =k;
          }
        }
        
      }    
    }        
  }
  
  return(list(i = i_star, j = j_star, k =k_star))
}



############################################################################
###################################################################################
######################################################################################
##############################################################################################3
###  Main auxiliary function for the last function

PTD_L1AB_unconstrained_2 <- function(Z,A,B,c1,c2,c3,Niter,kv,kw) 
{
  
  u = inits(dim(Z)[1])
  v = inits(dim(Z)[2])
  w = inits(dim(Z)[3])
  
  for(j in 1:5)
  {
    lizt <- list('mat2' = v,'mat3' =w)
    u =   ttl(Z, lizt, ms = c(2,3)) 
    u = t(as.matrix(u@data))
    u =  u/norm(u,"F")
    
    lizt <- list('mat2' = u,'mat3' =w)
    v =   ttl(Z, lizt, ms = c(1,3)) 
    v = t(as.matrix(v@data))
    v =  v/norm(v,"F")
    
    lizt <- list('mat2' = u,'mat3' =v)
    w =   ttl(Z, lizt, ms = c(1,2)) 
    w = t(as.matrix(w@data))
    w =  w/norm(w,"F")
  }
  
  
  
  
  
  #  u = PTDL1L1L1$u
  
  #  v = PTDL1L1L1$v
  #  w = PTDL1L1L1$w
  
  
  #w = PTDL1L1L1$w
  
  u_prev = u; v_prev = v; w_prev =w;
  
  lizt <- list('mat1' =u_prev,'mat2' = v_prev,'mat3' =w_prev)
  fprev =  ttl(Z, lizt, ms = c(1,2,3)) 
  
  fprev = fprev@data 
  
  # cl<-makeCluster(4)
  #registerDoSNOW(cl)
  for( iter in 1:Niter)
    #           foreach( iter in 1:20)%dopar%
  {
    #         print(iter)
    
    #  w = as.matrix( Unconstrained_GenLasso_update(Z,u,v,c3,B,3))
    #  if(length(which(w!=0))==0)
    #  {   iter = 42000; break}
    
    lizt <- list('mat2' = u,'mat3' =v)
    w =   ttl(Z, lizt, ms = c(1,2)) 
    #x = seq(0,1,length = length(as.vector(w@data)))
    w = glmgen::trendfilter( as.vector(w@data), k = kw , family = "gaussian", method = "admm", lambda = c3)
    w = predict(w, lambda = c3)
    w = t(as.matrix(w))
    w = w/norm(w,"F")
    
    u =  as.matrix(L1_update(Z,v,w,c1,1)) 
    if(length(which(u!=0))==0)
    {   iter = 42000; break}
    
    lizt <- list('mat2' = u,'mat3' =w)
    v =   ttl(Z, lizt, ms = c(1,3)) 
    #x = seq(0,1,length = length(as.vector(w@data)))
    v =  glmgen::trendfilter( as.vector(v@data), k = kv , family = "gaussian", method = "admm", lambda = c2)
    v = predict(v, lambda = c2)
    v = t(as.matrix(v))
    v = v/norm(v,"F")
    
    # v =   as.matrix(Unconstrained_GenLasso_update(Z,u,w,c2,A,2)) 
    #  if(length(which(v!=0))==0)
    #  {   iter = 42000; break}
    
    
    lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
    f =  ttl(Z, lizt, ms = c(1,2,3)) 
    f = f@data 
    
    aux = abs((f-fprev)/(fprev+ 0.0001))
    
    
    if( aux< 0.000001)
    { break}
    
    
    fprev = f
    u_prev = u; v_prev = v; w_prev =w;
  }
  
  
  lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
  d = ttl(Z, lizt, ms = c(1,2,3))  
  
  
  return(list(iter = iter, u = u, v= v, w=w,d=d)) 
}

#################################################################333

L1_update_unconstrained = function(X,u,v,c3,index)
{  
  if(index == 3)
  {   
    lizt <- list('mat1' = u,'mat2' = v)
    
    Y =  ttl(X, lizt, ms = c(1,2))
    Y =  unfold(Y,row_idx=3,col_idx=c(1,2))
    Y = t(Y@data)
  }
  if(index == 1)
  {   
    lizt <- list('mat1' = u,'mat2' = v)
    
    Y =  ttl(X, lizt, ms = c(2,3))
    # Y = unfold(Y,rs = c(2,3),cs=1)
    Y = unfold(Y,row_idx=1,col_idx=c(2,3))
    Y = t(Y@data)
  }
  
  if(index == 2)
  {   
    lizt <- list('mat1' = u,'mat2' = v)
    
    Y =  ttl(X, lizt, ms = c(1,3))
    Y =  unfold(Y,row_idx=2,col_idx=c(1,3))
    Y = t(Y@data)
  }
  
  aux = soft_tresholding(Y,c3)
  
  
  if( norm(aux,"F")==0)
  {
    return( matrix(0, dim(aux)[1],dim(aux)[2]) )
  }
  
  return( t(aux/ norm(aux,"F")) )
}  

#######################################################################################
#############################################################################################
#############################################################################################
##############################################################


PMD_T_FLFL <- function(Z,Z_training,Z_locations,c2,c3)
{
  
  dim = dim(Z)
  
  estimated = array(0, dim(Z)) 
  Z =  Z@data
  Z_training = Z_training@data
  Z_locations = Z_locations@data 
  
  v =   matrix(0,dim[1],dim[2])
  w =   matrix(0,dim[1],dim[3])
  par = matrix(0,dim[1],2) 
  
  for( i in  1:dim[1])
  {
    out= cv_PMD_T_FLFL(Z[i,,],Z_training[i,,],Z_locations[i,,],c2,c3) 
    
    v[i,] = as.vector(out$u)
    w[i,] = as.vector(out$v)
    par[i,1] = out$j
    par[i,2] = out$k
    
    aux = as.matrix(v[i,]) %*% t(as.matrix(w[i,]))
    d = t( as.matrix(v[i,]) ) %*% Z[i,,] %*% as.matrix(w[i,])
    estimated[i,,] = as.numeric(d) * aux
  }
  return(list(estimated=estimated,par=par))
}


#######################################################################################
#############################################################################################
#############################################################################################
##############################################################

cv_PMD_T_FLFL=  function(Z,Z_training,Z_locations,c2,c3)
{
  
  MSE  = Inf
  A =  fussed_lasso(nrow(Z))
  B =  fussed_lasso(ncol(Z))
  
  l = 0
  
  for(j in 1:length(c2))
  {
    for(k in 1:length(c3))
    {
      l = l+1
      # print(l)
      
      PTD = PTD_FLFL(Z_training,c2[j],c3[k],A,B,5)   
      
      iter = PTD$iter           
      
      if(iter < 42000)
      {
        u = PTD$u
        v = PTD$v
        
        
        g =  u %*% Z_training %*% t(v) 
        
        temp = Z_locations* (as.numeric(g)* t(u) %*% v) 
        X_aux2 = Z_locations * Z
        aux =  norm(temp-X_aux2,"F")
        
        if(  MSE > aux) 
        {
          MSE =  aux
          j_star =j;k_star =k;
        }
        #  print(MSE)
      }
    } 
  }
  PTD = PTD_FLFL(Z,c2[j_star],c3[k_star],A,B,20)
  
  u = PTD$u
  v = PTD$v
  
  
  return(list( u = u, v= v,j=j_star,k=k_star))      
  
}


#######################################################################################
#############################################################################################
#############################################################################################
##############################################################


PTD_FLFL =  function(Z,c2,c3,A,B,Niter)   
{
  u = inits(nrow(Z))
  v = inits(ncol(Z))
  
  u_prev = u; v_prev = v;
  
  fprev =  u %*% Z %*% t(v)  
  
  
  
  for( iter in 1:Niter)
  {
    #print(iter)
    
    #u =  t(as.matrix(as.vector(FL_update_PMD(Z,v,c2,1,A)))) 
    u = t(as.matrix(as.vector(FL_update_PMD_unconstrained(Z,v,c2,1,A)))) 
    if(length(which(u!=0))==0)
    {   iter = 42; break}
    
    #v =  t(as.matrix(as.vector(FL_update_PMD(Z,u,c3,2,B)))) 
    v = t(as.matrix(as.vector(FL_update_PMD_unconstrained(Z,u,c3,2,B)))) 
    if(length(which(v!=0))==0)
    {   iter = 42; break}
    
    f =  u %*% Z %*% t(v)  
    
    aux = abs((f-fprev)/(fprev+ 0.0001))
    
    
    if( aux< 0.00001)
    { break}
    
    
    fprev = f
  }

  d =  f 
  
  return(list(iter = iter, u = u, v= v, d=d))     
  
}





#############################################
#############################################################
#######################################################################################
#############################################################################################
#############################################################################################
################ Cross validation for L1L1 PMD for tensors



PMD_T_L1L1 <- function(Z,Z_training,Z_locations,c2,c3)
{
  
  dim = dim(Z)
  
  estimated = array(0, dim(Z)) 
  Z =  Z@data
  Z_training = Z_training@data
  Z_locations = Z_locations@data 
  
  v =   matrix(0,dim[1],dim[2])
  w =   matrix(0,dim[1],dim[3])
  par =  matrix(0,dim[1],2)
  
  for( i in  1:dim[1])
  {
    out= cv_PMD_T_L1L1(Z[i,,],Z_training[i,,],Z_locations[i,,],c2,c3) 
    
    v[i,] = as.vector(out$u)
    w[i,] = as.vector(out$v)
    par[i,1] = out$j
    par[i,2] = out$k      
    
    
    aux = as.matrix(v[i,]) %*% t(as.matrix(w[i,]))
    d = t( as.matrix(v[i,]) ) %*% Z[i,,] %*% as.matrix(w[i,])
    estimated[i,,] = as.numeric(d) * aux
  }
  return(list(estimated=estimated,par=par))
}


#######################################################################################
#############################################################################################
#############################################################################################
##############################################################




cv_PMD_T_L1L1=  function(Z,Z_training,Z_locations,c2,c3)
{
  
  MSE  = Inf
  
  l = 0
  
  for(j in 1:length(c2))
  {
    for(k in 1:length(c3))
    {
      l = l+1
      #   print(l)
      
      PTD = PMD_L1L1(Z_training,c2[j],c3[k],20) 
      
      iter = PTD$iter
      if(iter < 42)
      {
        u = PTD$u
        v = PTD$v   
        
        g =  u %*% Z_training %*% t(v) 
        
        temp = Z_locations* (as.numeric(g)* t(u) %*% v) 
        X_aux2 = Z_locations * Z
        aux =  norm(temp-X_aux2,"F")
        
        if(  MSE > aux) 
        {
          MSE =  aux
          j_star =j;k_star =k;
        }
        #  print(j_star)
        
        
      }
    } 
  }
  PTD = PMD_L1L1(Z,c2[j_star],c3[k_star],20)
  
  u = PTD$u
  v = PTD$v
  
  
  return(list( u = u, v= v,j=j_star,k=k_star))      
  
}

#######################################################################################
#############################################################################################
#############################################################################################
##############################################################




PMD_L1L1 =  function(Z,c2,c3,Niter)   
{
  
  u = inits(nrow(Z))
  v = inits(ncol(Z))
  
  
  for(j in 1:10)
  {
    u =   t(Z %*% t(v)) 
    u =  u/norm(u,"F")
    
    v =  u %*%  Z   
    v =  v/norm(v,"F")
  }
  
  
  
  
  
  u_prev = u; v_prev = v;
  
  fprev =  u %*% Z %*% t(v)  
  
  
  
  for( iter in 1:Niter)
  {
    #  print(iter)
    
    u = t(as.matrix(as.vector(L1_update_PMD(Z,v,c2,1)))) 
    if(length(which(u!=0))==0)
    {   iter = 42; break}
    
    v = t(as.matrix(as.vector(L1_update_PMD(Z,u,c3,2)))) 
    if(length(which(v!=0))==0)
    {   iter = 42; break}
    
    f =  u %*% Z %*% t(v)  
    
    aux = abs((f-fprev)/(fprev+ 0.0001))
    
    
    if( aux< 0.00001)
    { break}
    
    
    fprev = f
  }
  
  #print(aux)  
  
  f =  u %*% Z %*% t(v) 
  
  d =  f 
  
  return(list(iter = iter, u = u, v= v, d=d))     
  
}
#######################################################################################
#############################################################################################
#############################################################################################
##############################################################


L1_update_PMD =  function(Z,v,c3,indx)
{
  if(indx == 1)
  {
    Y  = t(Z %*% t(v))
  }
  if(indx  ==2)
  {
    Y  = v %*% Z      
  }
  
  Y = t(as.matrix(as.vector(Y)))
  aux = soft_tresholding(Y,c3)
  
  
  if( norm(aux,"F")==0)
  {
    return( matrix(0, dim(aux)[1],dim(aux)[2]) )
  }
  
  return( t(aux/ norm(aux,"F")) )
  #################################################################3w  
  
  
  
}

############################################
#############################################################
#######################################################################################
#############################################################################################
#############################################################################################
################ Cross validation for L1FL_PMD



PMD_T_FLL1 <- function(Z,Z_training,Z_locations,c2,c3)
{
  
  dim = dim(Z)
  
  estimated = array(0, dim(Z)) 
  Z =  Z@data
  Z_training = Z_training@data
  Z_locations = Z_locations@data 
  
  v =   matrix(0,dim[1],dim[2])
  w =   matrix(0,dim[1],dim[3])
  par = matrix(0,dim[1],2)
  
  for( i in  1:dim[1])
  {
    out= cv_PMD_T_FLL1(Z[i,,],Z_training[i,,],Z_locations[i,,],c2,c3) 
    
    v[i,] = as.vector(out$u)
    w[i,] = as.vector(out$v)
    par[i,1] = out$j
    par[i,2] = out$k    
    
    aux = as.matrix(v[i,]) %*% t(as.matrix(w[i,]))
    d = t( as.matrix(v[i,]) ) %*% Z[i,,] %*% as.matrix(w[i,])
    estimated[i,,] = as.numeric(d) * aux
  }
  return(list(estimated=estimated,par=par))
}


#######################################################################################
#############################################################################################
#############################################################################################
##############################################################




cv_PMD_T_FLL1=  function(Z,Z_training,Z_locations,c2,c3)
{
  
  A =  fussed_lasso(nrow(Z))
  
  MSE  = Inf
  
  l = 0
  
  for(j in 1:length(c2))
  {
    for(k in 1:length(c3))
    {
      l = l+1
      #   print(l)
      
      PTD = PMD_FLL1(Z_training,c2[j],c3[k],A,5) 
      
      iter =  PTD$iter
      
      if(iter<42)
      {
        
        u = PTD$u
        v = PTD$v 
        
        g =  u %*% Z_training %*% t(v) 
        
        temp = Z_locations* (as.numeric(g)* t(u) %*% v) 
        X_aux2 = Z_locations * Z
        aux =  norm(temp-X_aux2,"F")
        
        if(  MSE > aux) 
        {
          MSE =  aux
          j_star =j;k_star =k;
        }
        #    print(MSE)
        
      }
      
    }
  } 
  
  PTD = PMD_FLL1(Z,c2[j_star],c3[k_star],A,20)
  
  u = PTD$u
  v = PTD$v
  
  
  return(list( u = u, v= v,j=j_star,k=k_star)) 
}



#######################################################################################
#############################################################################################
#############################################################################################
##############################################################



PMD_FLL1 =  function(Z,c2,c3,A,Niter)   
{
  u = inits(nrow(Z))
  v = inits(ncol(Z))
  
  u_prev = u; v_prev = v;
  
  fprev =  u %*% Z %*% t(v)  
  
  
  
  for( iter in 1:Niter)
  {
    # print(iter)
    
    #  u =  t(as.matrix(as.vector(FL_update_PMD(Z,v,c2,1,A)))) 
    u =  t(as.matrix(as.vector(FL_update_PMD_unconstrained(Z,v,c2,1,A)))) 
    if(length(which(u!=0))==0)
    {   iter = 42; break}
    
    v =  t(as.matrix(as.vector(L1_update_PMD(Z,u,c3,2)))) 
    if(length(which(v!=0))==0)
    {   iter = 42; break}
    
    f =  u %*% Z %*% t(v)  
    
    aux = abs((f-fprev)/(fprev+ 0.0001))
    
    
    if( aux< 0.00001)
    { break}
    
    
    fprev = f
  }
  
  # print(aux)  
  f =  u %*% Z %*% t(v)  
  
  d =  f 
  
  return(list(iter = iter, u = u, v= v, d=d))     
  
}


#######################################################################################
#############################################################################################
#############################################################################################
##############################################################


unconstrained_updtade_adaptive = function(Y,v,w,ku,c1,index)
{
    if(index ==1)
    {
      lizt <- list('mat1' = v,'mat2' = w)
      
      Y =  ttl(X, lizt, ms = c(2,3))
      #  Y = unfold(Y,rs = c(2,3),cs=1)
      #  Y = Y@data
      Y =  unfold(Y,row_idx=1,col_idx=c(2,3))
      Y = t(Y@data)
    }
    
    if(index ==2)
    {
      lizt <- list('mat1' = v,'mat2' = w)
      
      Y =  ttl(X, lizt, ms = c(1,3))
      # Y = unfold(Y,rs = c(1,3),cs=2)
      #  Y = Y@data
      Y =  unfold(Y,row_idx=2,col_idx=c(1,3))
      Y = t(Y@data)
    }
    if(index ==3)
    {
      lizt <- list('mat1' = v,'mat2' = w)
      
      Y =  ttl(X, lizt, ms = c(1,2))
      #  Y = unfold(Y,rs = c(1,2),cs=3)
      #  Y = Y@data
      Y =  unfold(Y,row_idx=3,col_idx=c(1,2))
      Y = t(Y@data)
      
    } 
    response =  as.vector(Y)
    
    df = Inf
    test_length = floor(length(response)* .2)
    x = seq( 0,1,length= length(response))
    
    indexes = sort(sample.int( length(response),test_length,replace=FALSE))
    test_x = x[indexes]
    training_x  =  x[setdiff(1:length(response),indexes)]
    
    test_response = response[ indexes ]
    training_response = response[ setdiff(1:length(response),indexes) ]
    
    
    closest_index = apply( as.matrix(test_x),1, function(psi) {
      which.min( abs(psi - training_x) )
    } )       
    
    df = 10^15
    
    for(s in 1:length(c1))
    {
      sol =   glmgen::trendfilter(training_response, k = ku , family = "gaussian", method = "admm", lambda = c1[s])
      sol =  as.vector(predict(sol, lambda = c1[s]))
      
      df_s = sum((test_response - sol[closest_index] )^2)
      
      if(df_s < df)
      {
        w = sol
        df = df_s
        c1_star = c1[s]
      }#close if
      
    }
    #     
    sol =   glmgen::trendfilter(response, k = ku , family = "gaussian", method = "admm", lambda = c1_star)
    u =  as.vector(predict(sol, lambda = c1_star))
    
    u = t(as.matrix(u))
    u = u/norm(u,"F")
    
    return(u )
}


###############################################################
###############################################################
###############################################################
###############################################################



FL_update_PMD_unconstrained =  function(Z,v,c3,indx,A)
{
  if(indx == 1)
  {
    Y  = Z %*% t(v)
  }
  if(indx  ==2)
  {
    Y  = v %*% Z       
  }
  
  
  u = glmgen::trendfilter( as.vector(Y), k = 0 , family = "gaussian", method = "admm", lambda = c3)
  u =  predict(u,lambda = c3)
  
  u  = t(as.matrix(u))
  
  return(  u/norm(u,"F")  )
  
  ###################################  ###################################
  ###################################  ###################################
  Y = as.matrix(as.vector(Y))
  out = genlasso(y=as.vector(Y),D=A,minlam = c3)
  
  n = length(out$lambda)
  lambda = out$lambda 
  ###################################
  
  if(n==1 && out$lambda[n] < c3)
  {
    u = out$u[,1]
    u = Y - as.matrix(t(A) %*% as.vector(u))
    return( u/norm(u,"F"))
  }
  
  if(out$lambda[n]>c3)
  {
    u = (c3-lambda[n])/(lambda[n])*out$u[,n] + out$u[,n]
    u = Y - as.matrix(t(A) %*% as.vector(u)) 
    return( u/norm(u,"F"))
  }
  else
  {
    u = (c3-lambda[n-1])/(lambda[n]-lambda[n-1])*(out$u[,n]-out$u[,n-1]) + out$u[,n-1] 
    u = Y - as.matrix(t(A) %*% as.vector(u))
    return( u/norm(u,"F"))
  }
  
  
  
  
}




###################################################################################################
###################################################################################################
###################################################################################################

# 
# Rank_1_PTD_constrained_ABC <- function(Z,A,B,C, c1,c2,c3,Niter) 
# {
#   
#   u = inits(dim(Z)[1])
#   v = inits(dim(Z)[2])
#   w = inits(dim(Z)[3])
#   
#   for(j in 1:10)
#   {
#     lizt <- list('mat2' = v,'mat3' =w)
#     u =   ttl(Z, lizt, ms = c(2,3)) 
#     u = t(as.matrix(u@data))
#     u =  u/norm(u,"F")
#     
#     lizt <- list('mat2' = u,'mat3' =w)
#     v =   ttl(Z, lizt, ms = c(1,3)) 
#     v = t(as.matrix(v@data))
#     v =  v/norm(v,"F")
#     
#     lizt <- list('mat2' = u,'mat3' =v)
#     w =   ttl(Z, lizt, ms = c(1,2)) 
#     w = t(as.matrix(w@data))
#     w =  w/norm(w,"F")
#   }
#   
#   ####################################
#   I1  = 2 ##   genlasso penalty
#   if(sum(A*A) ==0)
#   {
#     I1 = 0  ###   no penalty
#   }
#   if( dim(A)[1]  == dim(A)[2]   )
#   {
#     if( sum(abs(diag(A)- rep(1,dim(A)[1]))) ==0   )
#     {
#       I1 = 1  ###  lasso
#     }
#   }
#   
#   I2  = 2 ##   genlasso penalty
#   if(sum(B*B) ==0)
#   {
#     I2 = 0  ###   no penalty
#   }
#   if( dim(B)[1]  == dim(B)[2]   )
#   {
#     if( sum(abs(diag(B)- rep(1,dim(B)[1]))) ==0   )
#     {
#       I2 = 1  ###  lasso
#     }
#   }
#   
#   I3  = 2 ##   genlasso penalty
#   if(sum(C*C) ==0)
#   {
#     I3 = 0  ###   no penalty
#   }
#   if( dim(C)[1]  == dim(C)[2]   )
#   {
#     if( sum(abs(diag(C)- rep(1,dim(C)[1]))) ==0   )
#     {
#       I3 = 1  ###  lasso
#     }
#   }
#   ########################################3
#   u_prev = u; v_prev = v; w_prev =w;
#   
#   lizt <- list('mat1' =u_prev,'mat2' = v_prev,'mat3' =w_prev)
#   fprev =  ttl(Z, lizt, ms = c(1,2,3)) 
#   
#   fprev = fprev@data 
#   
#   
#   for( iter in 1:Niter)
#   {
#     ###############################################
#     
#     ###  update w
#     if(I3 == 0)
#     {
#       lizt <- list('mat2' = u,'mat3' =v)
#       w =   ttl(Z, lizt, ms = c(1,2)) 
#       w = t(as.matrix(w@data))
#       w =  w/norm(w,"F")
#     }
#     if(I3 == 1)
#     { 
#       w = t(as.matrix(L1_update_unconstrained(Z,u,v,c3,3))) 
#     }
#     if(I3 == 2)
#     {
#       w = GenLasso_update(Z,u,v,c3,C,3)
#     }
#     if(length(which(w!=0))==0)
#     {   iter = 42000; break}   
#     
#     ###  update u
#     if(I1 == 0)
#     {
#       lizt <- list('mat2' = v,'mat3' =w)
#       u =   ttl(Z, lizt, ms = c(2,3)) 
#       u = t(as.matrix(u@data))
#       u =  u/norm(u,"F")
#     }
#     if(I1 == 1)
#     { 
#       u =  t(as.matrix(L1_update_unconstrained(Z,v,w,c1,1))) 
#     }
#     if(I1 == 2)
#     {
#       u = GenLasso_update(Z,v,w,c1,A,1)
#     }
#     if(length(which(u!=0))==0)
#     {   iter = 42000; break}
#     ###  update v
#     if(I2 == 0)
#     {
#       lizt <- list('mat2' = u,'mat3' =w)
#       v =   ttl(Z, lizt, ms = c(1,3)) 
#       v = t(as.matrix(v@data))
#       v =  v/norm(v,"F")
#     }
#     if(I2 == 1)
#     { 
#       v = t(as.matrix(L1_update_unconstrained(Z,u,w,c2,2)))
#     }
#     if(I2 == 2)
#     {
#       v =  GenLasso_update(Z,u,w,c2,A,2)
#     }
#     if(length(which(v!=0))==0)
#     {   iter = 42000; break}
#     
#     ###############################################
#     lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
#     f =  ttl(Z, lizt, ms = c(1,2,3)) 
#     f = f@data 
#     
#     aux = abs((f-fprev)/(fprev+ 0.0001))
#     
#     
#     if( aux< 0.001)
#     { break}
#     
#     
#     fprev = f
#     u_prev = u; v_prev = v; w_prev =w;
#   }
#   
#   lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
#   d = ttl(Z, lizt, ms = c(1,2,3))  
#   
#   
#   return(list(iter = iter, u = u, v= v, w=w,d=d)) 
# }
# 
# ######
# 
# 


###################################################################################################
###################################################################################################
###################################################################################################

##  Function to compute Rank-1 decomposition 
## Z is the tensor input 
## ku, kv and kw are the trendfiltering ordering for the penalties, these are part of the objective function
## ku = -1 (kv = -1 or kw = -1 respectively)  means no constrain on u (v or w respectively)




Rank_1_PTD_unconstrained_ABC <- function(Z,ku,kv,kw, c1,c2,c3,Niter) 
{
  
  u = inits(dim(Z)[1])
  v = inits(dim(Z)[2])
  w = inits(dim(Z)[3])
  
  for(j in 1:10)
  {
    lizt <- list('mat2' = v,'mat3' =w)
    u =   ttl(Z, lizt, ms = c(2,3)) 
    u = t(as.matrix(u@data))
    u =  u/norm(u,"F")
    
    lizt <- list('mat2' = u,'mat3' =w)
    v =   ttl(Z, lizt, ms = c(1,3)) 
    v = t(as.matrix(v@data))
    v =  v/norm(v,"F")
    
    lizt <- list('mat2' = u,'mat3' =v)
    w =   ttl(Z, lizt, ms = c(1,2)) 
    w = t(as.matrix(w@data))
    w =  w/norm(w,"F")
  }
  
  ####################################
 
  ########################################3
  u_prev = u; v_prev = v; w_prev =w;
  
  lizt <- list('mat1' =u_prev,'mat2' = v_prev,'mat3' =w_prev)
  fprev =  ttl(Z, lizt, ms = c(1,2,3)) 
  
  fprev = fprev@data 
  
  
  for( iter in 1:Niter)
  {
    ###############################################
    
    ###  update w
    if(kw == -1)
    {
      lizt <- list('mat2' = u,'mat3' =v)
      w =   ttl(Z, lizt, ms = c(1,2)) 
      w = t(as.matrix(w@data))
      w =  w/norm(w,"F")
    }

    if(kw > -1)
    {
      w =  t(as.matrix(drop(unconstrained_updtade_adaptive(Y,u,v,kw,c3,3))))
    }
    if(length(which(w!=0))==0)
    {   iter = 42000; break}   
    
    ###  update u
    if(ku == -1)
    {
      lizt <- list('mat2' = v,'mat3' =w)
      u =   ttl(Z, lizt, ms = c(2,3)) 
      u = t(as.matrix(u@data))
      u =  u/norm(u,"F")
    }
    if(ku > -1)
    { 
      u =  t(as.matrix(drop(unconstrained_updtade_adaptive(Y,v,w,ku,c1,1))))
    }
    
    if(length(which(u!=0))==0)
    {   iter = 42000; break}
    ###  update v
    if(kv == -1)
    {
      lizt <- list('mat2' = u,'mat3' =w)
      v =   ttl(Z, lizt, ms = c(1,3)) 
      v = t(as.matrix(v@data))
      v =  v/norm(v,"F")
    }
    if(kv > -1)
    { 
      v =  t(as.matrix(drop(unconstrained_updtade_adaptive(Y,u,w,kv,c2,2))))
    }

    if(length(which(v!=0))==0)
    {   iter = 42000; break}
    
    ###############################################
    lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
    f =  ttl(Z, lizt, ms = c(1,2,3)) 
    f = f@data 
    
    aux = abs((f-fprev)/(fprev+ 0.0001))
    
    
    if( aux< 0.001)
    { break}
    
    
    fprev = f
    u_prev = u; v_prev = v; w_prev =w;
  }
  
  lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
  d = ttl(Z, lizt, ms = c(1,2,3))  
  
  
  return(list(iter = iter, u = u, v= v, w=w,d=d)) 
}

######








