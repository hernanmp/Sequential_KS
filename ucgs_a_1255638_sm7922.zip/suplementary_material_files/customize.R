




### Given a tensor Z and vectors u,v,w, we can take the product, using the library rTensor
###  Z x_1 u x_2 v by doing
##Y =  ttl(Z, lizt, ms = c(1,2))
##Y =  unfold(Z,row_idx=3,col_idx=c(1,2))
##Y = t(Y@data)

############
###### Constrained rank-1 problem generalized lasso  block update
## Given a tensor Y, and vectors v_{i_1} and v_{i_2}, i_1 < i_2,  i_1,i_2 \in \{1,2,3\} 
## to solve the problem
##  min                            \| Y \times_{i_1} v_{i_1} \times_{i_2} v_{i_2} - v \|_2^2   
##  subject to                      \| Av\|_1  \leq c
##                                   v^T v  \leq 1
##
## one can call:   
##  GenLasso_update(Y,v_{i_1},v_{i_2},c,A,  i )
## where \{ i \} =  \{1,2,3\} - \{ i_1,i_2 \}



###### Unconstrained rank-1 problem generalized lasso  block update
## To solve the problem
##  min              \| Y \times_{i_1} v_{i_1} \times_{i_2} v_{i_2} - v \|_2^2    +  \lambda \| Av \|_1
##  subject to       v^T v  \leq 1
##                  
## One can call:
## unconstrained_updtade_adaptive(Y,v_{i_1},v_{i_2},k,c1,index)
## where  k is the trend filtering order of the matrix A




###### Generic unconstrained rank-1 problems
##  To solve 
##  min                \|Y-g\, u\circ v\circ w \|_{F}^{2}   +  c1\| A u\|_1 +  c_2\| B v\|_1 +   c_3\| C w\|_1
## subejct to            \| u\|_2^2 \leq 1,     \| v\|_2^2 \leq 1,   \| w\|_2^2 \leq 1,
###  chosing the parameters adaptavily, we can call                 
##   Rank_1_PTD_unconstrained_ABC(Z,ku,kv,kw, c1,c2,c3,Niter) 
##  For more details see the function  "Rank_1_PTD_constrained_ABC" see the file  "utilities.R"



###  The functions above can be used as a subroutine to different optimization problems
### For examples of combinations of multiple factors see the file "utils.R"
##  in particular the function "multiple_factor"
