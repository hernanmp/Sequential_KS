
##  Script creating the tensors considered in our simulations

create_structures <- function()
{
  u_generative =  matrix(0,6,10)
  v_generative = matrix(0,6,1000)
  w_generative  = matrix(0,6,400)
  
  u_generative[1,1:10] = c(1,1,1,-1,-1,-1,0,0,0,0)
  v_generative[1,1:1000]  = c(rep(0,99),rep(1,401),rep(0,500))
  w_generative[1,1:400] = c(rep(-1,100),rep(0,100),rep(1,200))
  
  ## dataset 2
  u_generative[2,1:10] = c(0,0,0,-1,-1,-1,0,0,0,0)
  # v_generative[2,1:1000]  = c(rep(0,200),rep(-1,200),rep(0,500),rep(1,100))
  #  w_generative[2,1:400] = c(rep(-1,80),rep(0,120),rep(1,50),rep(0,150))
  v_generative[2,1:1000] = seq(0,1,length= 1000)
  w_generative[2,1:400]  =  seq(0,1,length= 400)
  v_generative[2,1:1000] = cos(12*pi* v_generative[2,1:1000] )
  w_generative[2,1:400] = cos(9*pi* w_generative[2,1:400] )
  ## dataset 3
  u_generative[3,1:10] = c(0,0,0,0,-1,-1,1,1,1,1)
  v_generative[3,1:1000]  = seq(0,1,length= 1000)
  w_generative[3,1:400] =  seq(0,1,length= 400)
  v_generative[3,1:1000]  =  (  v_generative[3,1:1000]-0.7)^2 +   v_generative[3,1:1000]*  v_generative[3,1:1000]  
  w_generative[3,1:200] =  w_generative[3,1:200]* (0.05-w_generative[3,1:200])
  w_generative[3,201:400] =  w_generative[3,201:400] *(w_generative[3,201:400])  
  v_generative[3,1:500] =    v_generative[3,1:500]/2
  #w_generative[3,1:200] =  w_generative[3,1:200]/4
  #w_generative[3,1:400]=  w_generative[3,1:400]* w_generative[3,1:400]*( w_generative[3,1:400]-2)^2
  ## dataset 4
  u_generative[4,1:10] = c(0,0,0,0,0,1,1,1,1,1)
  w_generative[4,1:400]  = c(rep(0,100),rep(1,50),rep(0,150),rep(1,50),rep(0,50))
  v_generative[4,1:1000] =  seq(0,1,length= 1000)
  #w_generative[4,1:400]  = (  w_generative[3,1:400]-0.7)^2 +   w_generative[3,1:400]*  v_generative[3,1:400]  
  #v_generative[4,1:500] =   (  v_generative[4,1:500]-0.7)^2 +   v_generative[4,1:500]*v_generative[4,1:500] 
  #  v_generative[4,1:1000] =  cos(  v_generative[4,1:1000]*2*3.1415) + 0.65
  v_generative[4,] = cos(  v_generative[4,1:1000]*2*3.1415) + 0.65
  
  ## dataset 5
#   u_generative[6,1:10] = c(-1,-1,0,0,1,1,1,-1,-1,-1)
#   v_generative[6,1:1000]  = seq(0,1,length= 1000)
#   v_generative[6,400:500]  =((  v_generative[6,400:500]-0.7)^2 +  v_generative[6,400:500]*  v_generative[6,400:500])
#   v_generative[6,1:399] = rep(0,399)
#   v_generative[6,501:1000] = rep(0,500)
#   w_generative[6,1:400] = c(rep(-1,100),rep(0,100),rep(1,200))   
#   
  ## dataset 5
  u_generative[5,1:10] = c(-1,-1,0,0,1,1,1,-1,-1,-1)
  v_generative[5,1:1000]  = c(rep(0,1000))
  w_generative[5,1:400] =   rep(0,400)
  
  indx =  sample(1:1000, 200, replace = TRUE) 
  #indx2 =  sample(1:1000, 50, replace = TRUE) 
  v_generative[5,indx] = rnorm(200)
  #v_generative[5,indx2] = rnorm(50)
  
  indx =  sample(1:400, 30, replace = TRUE) 
  #indx2 =  sample(1:400, 60, replace = TRUE) 
  w_generative[5,indx] = rnorm(30)
  #w_generative[5,indx2] =rnorm(60)
  
  return(list(u_generative = u_generative, v_generative = v_generative, w_generative = w_generative ))
  
}
