
###  simulations for rank 3 tensors choosing the tuning prameters adpatively
### this corresponds to part of Table 3 in the paper

### This is supported by the following R packages:

##  R package Matrix:
##  Douglas Bates and Martin Maechler. Matrix: Sparse and Dense Matrix Classes and Methods. 2005. R package version 1.2-2.
##  Available at: http://CRAN.R-project.org/package=Matrix

##  R package glmgen:
##  Taylor Arnold and Veeranjaneyulu Sadhanala and Ryan Tibshirani. glmgen: Fast algorithms for generalized lasso problems. 2014. R package version 0.0.3.
##  Available at: https://github.com/statsmaths/glmgen


## Rpackage genlasso:
## Taylor B. Arnold and Ryan J. Tibshirani. genlasso: Path algorithm for generalized lasso problems. 2014. 
## available at: http://CRAN.R-project.org/package=genlasso

## Rpackage rTensor:
## James Li and Jacob Bien and Martin Wells. rTensor: Tools for tensor analysis and decomposition. 2014. R package version 1.2.
## available at: http://CRAN.R-project.org/package=rTensor


rm(list = ls())

setwd("/Users/user/Documents/tensors/tex/jcgs-template/Final_version/code")


library(Matrix)
library(rTensor)
library(genlasso)
source("utilities.R")
source("cross_validation.R")
source("create_structures.R")
library(glmgen)
source("utils.R")
#source("anandkumar.R")


temp =  create_structures()
###  True vectors


u_generative = temp$u_generative 
v_generative = temp$v_generative 
w_generative = temp$w_generative   


# satndard deviation of noise
sigma = 1  

##  Rank 3  examples

#rank2 =  matrix(0,6,2)
rank3 = matrix(0,4,3)

rank3[1,] = c(1,2,3)
rank3[2,] = c(1,2,4)
rank3[3,] = c(1,3,4)
rank3[4,] = c(2,3,4)



# tuning parameters grids
c1 = c(1.2,2,3)   
c2 =  c(.005,.5,5,10,20,100,300,500)
c3 =  c(.005,.5,5,10,20,100,300,500)
c11 = c1
c22 = c2
c33 = c3


# number of factors
K = 3
Num_trials = 100
error_anandkumar = matrix(0,4,Num_trials )
error_L1FLFL = matrix(0,4,Num_trials )
error_L1TFTF = matrix(0,4,Num_trials )


###  loop for different sturctures
for( ind  in 1:4)#dim(rank3)[1])
{
  
  
  print(ind)
  
  
  i1 =  rank3[ind,1]
  i2 =  rank3[ind,2]
  i3 =  rank3[ind,3]
  
  ###  loop for different MC trials
  for(trial in 1:100)
  {
    ### Generate data
    print(trial)
    
    temp2 = Generate_data(u_generative[i1,],v_generative[i1,],w_generative[i1,],sigma)
    X = temp2$X_raw
    
    ## adding second component
    lizt <- list('mat' = as.matrix(u_generative[i2,]),'mat2' = as.matrix(v_generative[i2,]),'mat3'= as.matrix(w_generative[i2,]) )
    Y =   ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    X = X +Y
    
    ## adding third component
    lizt <- list('mat' = as.matrix(u_generative[i3,]),'mat2' = as.matrix(v_generative[i3,]),'mat3'= as.matrix(w_generative[i3,]) )
    Y =   ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    X = X +Y
    temp2 = c()
    T = X
    
    
    #  construct true mean tensor 
    lizt <- list('mat' = as.matrix(u_generative[i1,] ),'mat2' = as.matrix(v_generative[i1,]),'mat3'= as.matrix(w_generative[i1,] ) )
    true = ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    lizt <- list('mat' = as.matrix(u_generative[i2,] ),'mat2' = as.matrix(v_generative[i2,]),'mat3'= as.matrix(w_generative[i2,] ) )
    true = true +   ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    lizt <- list('mat' = as.matrix(u_generative[i3,] ),'mat2' = as.matrix(v_generative[i3,]),'mat3'= as.matrix(w_generative[i3,] ) )
    true = true +   ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))    
    
    
    ####### Anadkumar
    temp = anandkumar(X,L=20,N = 5,K=3,par_v = .9)
    
      aaa =max(c( abs(sum(temp$a_hat[1,]*temp$a_hat[2,])),abs(sum(temp$b_hat[1,]*temp$b_hat[2,])) ,abs(sum(temp$c_hat[1,]*temp$c_hat[2,]))  ))
      
      
      # disregard hihgly correlated factors
      if(aaa > .95)
      {
        temp$a_hat[2,] = rep(0,dim(X)[1])
        temp$b_hat[2,] = rep(0,dim(X)[2])
        temp$c_hat[2,] = rep(0,dim(X)[3])
      }
      aaa =max(c( abs(sum(temp$a_hat[1,]*temp$a_hat[3,])),abs(sum(temp$b_hat[1,]*temp$b_hat[3,])) ,abs(sum(temp$c_hat[1,]*temp$c_hat[3,]))  ))
      
      if(aaa > .95)
      {
        temp$a_hat[3,] = rep(0,dim(X)[1])
        temp$b_hat[3,] = rep(0,dim(X)[2])
        temp$c_hat[3,] = rep(0,dim(X)[3])
      }
 
      aaa =max(c( abs(sum(temp$a_hat[2,]*temp$a_hat[3,])),abs(sum(temp$b_hat[2,]*temp$b_hat[3,])) ,abs(sum(temp$c_hat[2,]*temp$c_hat[3,]))  ))
  
      if(aaa > .95)
      {
       temp$a_hat[3,] = rep(0,dim(X)[1])
       temp$b_hat[3,] = rep(0,dim(X)[2])
       temp$c_hat[3,] = rep(0,dim(X)[3])
      }
     
    ####
    weights = rep(0,K)
    
    weights[1] = product(X,c(1,2,3),temp$a_hat[1,],temp$b_hat[1,],temp$c_hat[1,]) 
    weights[2] = product(X,c(1,2,3),temp$a_hat[2,],temp$b_hat[2,],temp$c_hat[2,]) 
    weights[3] = product(X,c(1,2,3),temp$a_hat[3,],temp$b_hat[3,],temp$c_hat[3,]) 
        
    lizt <- list('mat' = as.matrix(temp$a_hat[1,] ),'mat2' = as.matrix(temp$b_hat[1,]),'mat3'= as.matrix(temp$c_hat[1,] ) )
    aux =  weights[1]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    lizt <- list('mat' = as.matrix(temp$a_hat[2,] ),'mat2' = as.matrix(temp$b_hat[2,]),'mat3'= as.matrix(temp$c_hat[2,] ) )
    aux =  aux +  weights[2]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    lizt <- list('mat' = as.matrix(temp$a_hat[3,] ),'mat2' = as.matrix(temp$b_hat[3,]),'mat3'= as.matrix(temp$c_hat[3,] ) )
    aux =  aux +  weights[3]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    #############
    
    ## prepare initials for PTD
  
    if( sum((temp$a_hat[1,])^2)==0)
    {
      temp$a_hat[1,] = temp$a_hat[2,]
      temp$b_hat[1,] = temp$b_hat[2,]
      temp$c_hat[1,] = temp$c_hat[2,]
    }
    if( sum((temp$a_hat[2,])^2)==0)
    {
      temp$a_hat[2,] = temp$a_hat[1,]
      temp$b_hat[2,] = temp$b_hat[1,]
      temp$c_hat[2,] = temp$c_hat[1,]
    }
    if( sum((temp$a_hat[3,])^2)==0)
    {
      temp$a_hat[3,] = temp$a_hat[1,]
      temp$b_hat[3,] = temp$b_hat[1,]
      temp$c_hat[3,] = temp$c_hat[1,]
    }
    #########################################################################33333 
    ###### PTD(L1,FL,FL)
    Av = fussed_lasso(length(v_generative[1,]))
    Aw = fussed_lasso(length(w_generative[1,]))
    kv = 0
    kw = 0
    
    A = Av
    B = Aw
    
    
    
    temp2 = multiple_factors(X,K,temp$a_hat,temp$b_hat,temp$c_hat,c11,c22,c33,10,kv,kw)
    
    ## in first iteration we select reasonale parameters to use in the following trials
    if(trial== 1)
    {
        c11 =  unique(temp2$c1_star) 
        c22 =  unique(temp2$c2_star) 
        c33 =  unique(temp2$c3_star) 
    }
    
    lizt <- list('mat' = as.matrix(temp2$a_hat[1,] ),'mat2' = as.matrix(temp2$b_hat[1,]),'mat3'= as.matrix(temp2$c_hat[1,] ) )
    aux2 =  temp2$w_hat[1]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    lizt <- list('mat' = as.matrix(temp2$a_hat[2,] ),'mat2' = as.matrix(temp2$b_hat[2,]),'mat3'= as.matrix(temp2$c_hat[2,] ) )
    aux2 = aux2 +   temp2$w_hat[2]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
   
    lizt <- list('mat' = as.matrix(temp2$a_hat[3,] ),'mat2' = as.matrix(temp2$b_hat[3,]),'mat3'= as.matrix(temp2$c_hat[3,] ) )
    aux2 = aux2 +   temp2$w_hat[3]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    #########################################################################33333  
    ###### PTD(L1,FL,FL)
    
    Av = trend_filtering(1,length(v_generative[1,]))
    Aw =  trend_filtering(1,length(w_generative[1,]))
    kv = 1
    kw = 1
    
    A = Av
    B = Aw
    
    
    temp3 = multiple_factors(X,K,temp2$a_hat,temp2$b_hat,temp2$c_hat,c1,c2,c3,5,kv,kw)
    
    
    if(trial == 1)
    {
      c1 =  unique(temp3$c1_star) 
      c2 =  unique(temp3$c2_star) 
      c3 =  unique(temp3$c3_star) 
    }
    
    ## prepare estimated tensor
    lizt <- list('mat' = as.matrix(temp3$a_hat[1,] ),'mat2' = as.matrix(temp3$b_hat[1,]),'mat3'= as.matrix(temp3$c_hat[1,] ) )
    aux3 =  temp3$w_hat[1]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    lizt <- list('mat' = as.matrix(temp3$a_hat[2,] ),'mat2' = as.matrix(temp3$b_hat[2,]),'mat3'= as.matrix(temp3$c_hat[2,] ) )
    aux3 = aux3 +   temp3$w_hat[2]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    lizt <- list('mat' = as.matrix(temp3$a_hat[3,] ),'mat2' = as.matrix(temp3$b_hat[3,]),'mat3'= as.matrix(temp3$c_hat[3,] ) )
    aux3 = aux3 +   temp3$w_hat[3]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    
    #########################################################################33333  
    ###### Compute errors
    error_anandkumar[ind,trial] = fnorm(aux-true)
    error_L1FLFL[ind,trial] =  fnorm(aux2-true)
    error_L1TFTF[ind,trial] = fnorm(aux3-true)
  
    
  }###  close for trial
  
}### close for structure

#############################
##  The results are stored in error_anandkumar, error_L1FLFL and error_L1TFTF
## To see for example for the tensor sum of structures 2,3 and 4, we can do
ind = 4
print(mean(error_anandkumar[ind,]))
print(mean(error_L1FLFL[ind,]))
print(mean(error_L1TFTF[ind,]))
