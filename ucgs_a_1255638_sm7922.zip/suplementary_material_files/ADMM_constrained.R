## Here is the code for the Rank-1 PTD algorithm based on the ADMM algorithm from  "Y. Zhu. An augmented admm algorithm with application to the generalized lasso problem.
#Journal of Computational and Graphical Statistics, (just-accepted), 2015."
# This also uses the L1 projection method from 
#"J. Duchi, S. Shalev-Shwartz, Y. Singer, and T. Chandra. Efficient projections onto the l
#1-ball for learning in high dimensions. In Proceedings of the 25th international conference
#on Machine learning, pages 272-279. ACM, 2008."

### This is supported by the following R packages:

##  R package Matrix:
##  Douglas Bates and Martin Maechler. Matrix: Sparse and Dense Matrix Classes and Methods. 2005. R package version 1.2-2.
##  Available at: http://CRAN.R-project.org/package=Matrix

##  R package glmgen:
##  Taylor Arnold and Veeranjaneyulu Sadhanala and Ryan Tibshirani. glmgen: Fast algorithms for generalized lasso problems. 2014. R package version 0.0.3.
##  Available at: https://github.com/statsmaths/glmgen


## Rpackage genlasso:
## Taylor B. Arnold and Ryan J. Tibshirani. genlasso: Path algorithm for generalized lasso problems. 2014. 
## available at: http://CRAN.R-project.org/package=genlasso

## Rpackage rTensor:
## James Li and Jacob Bien and Martin Wells. rTensor: Tools for tensor analysis and decomposition. 2014. R package version 1.2.
## available at: http://CRAN.R-project.org/package=rTensor




PTD_ADMM_constrained <- function(Z,A,B,u,v,w, c1,c2,c3,Epsilon = 1,Niter,num_iter) 
{
  ## epsilon is unused in this version
  
  u =  t(as.matrix(u))
  v =  t(as.matrix(v))
  w =  t(as.matrix(w))

  u_prev = u; v_prev = v; w_prev =w;
  
  lizt <- list('mat1' =u_prev,'mat2' = v_prev,'mat3' =w_prev)
  fprev =  ttl(Z, lizt, ms = c(1,2,3)) 
  
  fprev = fprev@data 
  
  
  for( iter in 1:Niter)
  {
    c3
    w = t(as.matrix(GenLasso_update_ADMM_constrained(Z,u,v,c3,B,3,num_iter) ))

    if(length(which(w!=0))==0)
    {   iter = 42; break}
    
    u =  as.matrix(L1_update(Z,v,w,c1,1)) 
    if(length(which(u!=0))==0)
    {   iter = 42; break}
    
    v =  t(as.matrix(GenLasso_update_ADMM_constrained(Z,u,w,c2,A,2,num_iter)))

    if(length(which(v!=0))==0)
    {   iter = 42; break}
    
 
    lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
    f =  ttl(Z, lizt, ms = c(1,2,3)) 
    f = f@data 
    
    aux = abs((f-fprev)/(fprev+ 0.0001))
    
    if(aux < 10^-3)
    { break;}
    
    
    fprev = f
    u_prev = u; v_prev = v; w_prev =w;
  }

  lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
  d = ttl(Z, lizt, ms = c(1,2,3))  
  
  
  return(list(iter = iter, u = u, v= v, w=w,d=d)) 
}

########################################################################################
########################################################################################
########################################################################################


GenLasso_update_ADMM_constrained <-  function(X,v,w,c3,A,index,num_iter)
{
  if(index ==1)
  {
    lizt <- list('mat1' = v,'mat2' = w)
    
    Y =  ttl(X, lizt, ms = c(2,3))
    Y =  unfold(Y,row_idx=1,col_idx=c(2,3))
    Y = t(Y@data)
  }
  
  if(index ==2)
  {
    lizt <- list('mat1' = v,'mat2' = w)
    
    Y =  ttl(X, lizt, ms = c(1,3))
    Y =  unfold(Y,row_idx=2,col_idx=c(1,3))
    Y = t(Y@data)
  }
  if(index ==3)
  {
    lizt <- list('mat1' = v,'mat2' = w)
    
    Y =  ttl(X, lizt, ms = c(1,2))
    Y =  unfold(Y,row_idx=3,col_idx=c(1,2))
    Y = t(Y@data)
    
  } 
  y = as.vector(Y)
  D = t(A)%*%A
  d =  norm(D,type = "o") + 10
  D = Diagonal(dim(D)[1],d) 
  
  theta_u = rep(1,length(y))
  gamma_u = rep(1, dim(A)[1])
  alpha_u = gamma_u
 
  rho = 10
    
  theta_u_prev = rep(1,length(y))
  gamma_u_prev = rep(1, dim(A)[1])
  alpha_u_prev = gamma_u
  
  theta_u_prev_prev = rep(1,length(y))
  gamma_u_prev_prev = rep(1, dim(A)[1])
  alpha_u_prev_prev = gamma_u


  ki = length(gamma_u)
    
  for(iter in 1:num_iter)
  {
   theta_u =  y/2 - as.vector(t(A)%*%(alpha_u_prev - .5*alpha_u_prev_prev)) + rho*d/2*theta_u_prev
    theta_u = theta_u/sqrt(sum(theta_u*theta_u))
      
      ## update gamma,projection onto unit L1-ball
      
      a = as.vector(A%*%theta_u  + 1/rho*alpha_u_prev)
      
      gamma_u = L1_projection(a,c3)
      
      ### update alpha
      
      alpha_u = as.vector(alpha_u_prev + rho*(A%*%theta_u - gamma_u))
############################################################################3
       if(1 == 1)
       {
         ## update r and s
         
         r_u =  A%*%theta_u - gamma_u
         s_u = rho*t(A)%*%(gamma_u - gamma_u_prev)
         
         ##update  rho
          epsilon_abs = 10^-6
          epsilon_rel = 10^-4 
          
          epsilon_pri = sqrt(dim(A)[1])*epsilon_abs +  epsilon_rel*max(sqrt(sum((as.vector(A%*% theta_u))^2)),sqrt(sum((gamma_u)^2)))
          epsilon_dual = sqrt(dim(A)[2])*epsilon_abs  +  epsilon_rel*sqrt(sum((as.vector( t(A)%*%alpha_u ))^2))
          
         
         ##################################33333
         
         aux = sum((r_u )^2)/epsilon_pri  - 10* sum((s_u )^2)/epsilon_dual
         aux2 = sum((s_u )^2)/epsilon_dual - 10*sum((r_u )^2)/epsilon_pri
         
         if(aux > 0)
         {
           rho = 2*rho
         }
         if(aux2 > 0)
         {
           rho = .5*rho
         }
         
         if( sum(r_u^2) < epsilon_pri &&  sum(s_u^2) < epsilon_dual)
         {
           return(theta_u)
         }
         
          ki = ki + sqrt(iter) 
          
       }
############################################################################3   
      if(iter > 2)
      {
        alpha_u_prev_prev = alpha_u_prev
        alpha_u_prev = alpha_u
        
        gamma_u_prev_prev = gamma_u_prev
        gamma_u_prev = gamma_u
        
        theta_u_prev_prev = theta_u_prev
        theta_u_prev = theta_u
      }
      

      
      ##  
  }
  

  
  return(theta_u)
  
}

############



L1_projection = function(a,c3)
{
  n = length(a)
  s = 0
  rho = 0
  U = 1:n
  
  while(  length(U) >0)
  {
     k = sample(U,1)
     
     ind = which(a[U]>= a[k])
     G = U[ind]
     L = U[-ind]
     
     delta_rho  = length(G)
     delta_s = sum(a[G])
     
     if( (s+delta_s)-(rho+delta_rho)*a[k] < c3 )
     {
         s = s+delta_s
         rho = rho+delta_rho
         U = L
     }
     else
     {
       U = setdiff(G,c(k))
     }
  }
  theta = (s-c3)/rho
  
  out  = a - theta
  ind = which(out <0)  
  out[ind] = 0
  out = sign(a)*out
  return(out)
}





















