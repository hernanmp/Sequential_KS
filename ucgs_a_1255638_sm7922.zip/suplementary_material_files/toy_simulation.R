
## Simulation for Figure 1
### This is supported by the following R packages:

##  R package Matrix:
##  Douglas Bates and Martin Maechler. Matrix: Sparse and Dense Matrix Classes and Methods. 2005. R package version 1.2-2.
##  Available at: http://CRAN.R-project.org/package=Matrix

##  R package glmgen:
##  Taylor Arnold and Veeranjaneyulu Sadhanala and Ryan Tibshirani. glmgen: Fast algorithms for generalized lasso problems. 2014. R package version 0.0.3.
##  Available at: https://github.com/statsmaths/glmgen


## Rpackage genlasso:
## Taylor B. Arnold and Ryan J. Tibshirani. genlasso: Path algorithm for generalized lasso problems. 2014. 
## available at: http://CRAN.R-project.org/package=genlasso

## Rpackage rTensor:
## James Li and Jacob Bien and Martin Wells. rTensor: Tools for tensor analysis and decomposition. 2014. R package version 1.2.
## available at: http://CRAN.R-project.org/package=rTensor



rm(list = ls())


setwd("/Users/user/Documents/tensors/tex/jcgs-template/Final_version/code")


library(Matrix)
library(rTensor)
library(genlasso)
source("utilities.R")
source("cross_validation.R")
source("create_structures.R")
source("ADMM_constrained.R")
library(glmgen)
source("utils.R")
###  simulations for rank 2 tensors choosing the tuning pramters adpatively
# 
temp =  create_structures()
###  True vectors

u_generative = temp$u_generative 
v_generative = temp$v_generative 
w_generative = temp$w_generative  

# satndard deviation of noise
sigma = 1  

## Number of MC simulations
NMC = 1


c1 = c(1.2,2,3)    # tuning parameters grid for first  mode, this appears in the constrain set
c2 = c(.005,.5,5,10,20,100,300,500)# tuning parameters grid for second mode, this appears in the obejective
c3 = c(.005,.5,5,10,20,100,300,500)# tuning parameters grid for third mode,  this appears in the obejective


##############################################


v_size_grid = 500*seq(1,20,length=20)

Num_experiments = length(v_size_grid)

admm_error = matrix(0,NMC,Num_experiments)
constrained_error = matrix(0,NMC,Num_experiments)
constrained_time = matrix(0,NMC,Num_experiments)
admm_time  = matrix(0,NMC,Num_experiments)
constrained_ADMM_error = matrix(0,NMC,Num_experiments)
constrained_ADMM_time = matrix(0,NMC,Num_experiments)




for(ind in 1:20)
{
  ###  generate data
  
  print(ind)
  
  true_u = c(0,0,0,0,-1,-1,1,1,1,1)
  
 # print("L1 norm of u")
#  print( sum(abs(true_u/ sqrt(sum(true_u*true_u)))))
  
  true_w  =  seq(0,1,length= 400)
  true_w   = cos(9*pi* true_w   )
  
  true_v = seq(0,1,length = v_size_grid[ind] )
  true_v  =  cos(12*pi* true_v )
  
  
  for(iter in 1:NMC)
  {
    temp2 = Generate_data(true_u,true_v,true_w,sigma)
    X = temp2$X_raw 
    
    lizt <- list('mat' = as.matrix(true_u ),'mat2' = as.matrix(true_v),'mat3'= as.matrix(true_w) )
    true = ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    ##################################################
    u = inits(dim(X)[1]) 
    v = inits(dim(X)[2]) 
    w = inits(dim(X)[3]) 
    
    
    temp4 = simple_factor_model(X,1,u,v,w,c1,c2,c3,10,kv,kw)
    
    
    ###  constrained
    
    Av = trend_filtering(1,length( true_v )  )
    Aw =  trend_filtering(1,length( true_w ))
    kv = 1
    kw = 1
    
    A = Av
    B = Aw
    
    cv =   sum(abs(A %*% true_v))/sqrt(sum(true_v*true_v))
    cw =   sum(abs(B %*% true_w))/sqrt(sum(true_w*true_w))
    
    
    aa = system.time({ temp2  = PTD_constrained(X,A,B,temp4$a_hat[1,],temp4$b_hat[1,],temp4$c_hat[1,], 10,cv,cw,1) })  
    
    lizt <- list('mat' = t(as.matrix(temp2$u )),'mat2' = t(as.matrix(temp2$v)),'mat3'= t(as.matrix(temp2$w )) )    
    constrained_error[iter,ind]  = fnorm( true - (temp2$d)@data[1,1,1]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3)  ))
    constrained_time[iter,ind] = aa[1] 
    
 
    ## ADMM constrained  
    source("ADMM_constrained.R")
    aa = system.time({ temp3 =  PTD_ADMM_constrained(X,A,B,temp4$a_hat[1,],temp4$b_hat[1,],temp4$c_hat[1,], 3,cv,cw,Epsilon,10,2000) })
    lizt <- list('mat' = t(as.matrix(temp3$u )),'mat2' = t(as.matrix(temp3$v)),'mat3'= t(as.matrix(temp3$w )) )
    constrained_ADMM_error[iter,ind] =   fnorm( true - (temp3$d)@data[1,1,1]*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3)  ))  
    constrained_ADMM_time[iter,ind] = aa[1]
    
    
    new_v = as.vector(temp3$v)
    new_w = as.vector(temp3$w)
    cv2 =   sum(abs(A %*% new_v))/sqrt(sum(new_v*new_v))
    cw2 =   sum(abs(B %*% new_w))/sqrt(sum(new_w*new_w))
    
    
    
    ##### unconstrained
    aa = system.time({   temp2 = multiple_factors(X,1,temp4$a_hat,temp4$b_hat,temp4$c_hat,c1,c2,c3,10,kv,kw) } )
    
    
    lizt <- list('mat' = as.matrix(temp2$a_hat[1,] ) ,'mat2' = as.matrix(temp2$b_hat[1,] ),'mat3'= as.matrix(temp2$c_hat[1,] ) )  
    admm_error[iter,ind]  = fnorm( true - temp2$w_hat*ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3)  ) )
    admm_time[iter,ind] = aa[1] 
  }### close for MC simulations
}#close


 ## Frobenius errror for unconstrained ADMM  
 admm_error = colMeans( admm_error)
 ## Time for unconstrained ADMM    
 admm_time = colMeans( admm_time)
  
 ## Frobenius errror for constrained solution path based method  
 constrained_error = colMeans( constrained_error)
 ## Time for constrained solution path based method   
 constrained_time = colMeans( constrained_time)
 
 ## Frobenius errror for constrained solution path based method  
 constrained_ADMM_error = colMeans( constrained_ADMM_error)
 ## Time for constrained solution path based method   
 constrained_ADMM_time = colMeans( constrained_ADMM_time)
 
matplot(cbind(admm_error,constrained_error,constrained_ADMM_error),type="l")
axis(1, at = c(1,5,10,15,20), labels = v_size_grid[ c(1,5,10,15,20)])# cex.axis = 0.7
legend("topleft", legend=c( "Unconstrained version","Solution path constrained","ADMM Constrained "),cex =1.75, pch=c(1,2,3), col=c(1,2,3), horiz= FALSE)

matplot(cbind(admm_time,constrained_time,constrained_ADMM_time) ,type="l")
axis(1, at = c(1,5,10,15,20), labels = v_size_grid[ c(1,5,10,15,20)])# cex.axis = 0.7
legend("topleft", legend=c( "Unconstrained version","Solution path constrained","ADMM Constrained "),cex =1.75, pch=c(1,2,3), col=c(1,2,3), horiz= FALSE)



