
### This is supported by the following R packages:

##  R package Matrix:
##  Douglas Bates and Martin Maechler. Matrix: Sparse and Dense Matrix Classes and Methods. 2005. R package version 1.2-2.
##  Available at: http://CRAN.R-project.org/package=Matrix

##  R package glmgen:
##  Taylor Arnold and Veeranjaneyulu Sadhanala and Ryan Tibshirani. glmgen: Fast algorithms for generalized lasso problems. 2014. R package version 0.0.3.
##  Available at: https://github.com/statsmaths/glmgen


## Rpackage genlasso:
## Taylor B. Arnold and Ryan J. Tibshirani. genlasso: Path algorithm for generalized lasso problems. 2014. 
## available at: http://CRAN.R-project.org/package=genlasso

## Rpackage rTensor:
## James Li and Jacob Bien and Martin Wells. rTensor: Tools for tensor analysis and decomposition. 2014. R package version 1.2.
## available at: http://CRAN.R-project.org/package=rTensor



###  Function to compute the the product of a tensor with two different vectors along two modes

product = function(X,ind,u,v,w)
{
   u = t(as.matrix(u))
   v = t(as.matrix(v))
   w = t(as.matrix(w))
    
   
   if(length(ind ) ==2)
   {
     lizt <- list('mat2' = u,'mat3' =v)
     u =   ttl(X, lizt, ms = ind)
     return( as.vector(u@data))
   }
   
   lizt <- list('mat' = u,'mat2' =v,'mat3'=w)
   u =   ttl(X, lizt, ms = ind)
   return( as.vector(u@data))

}
################################################################
###  Function to fit the method from anandkumar

anandkumar = function(T,L,N,K,par_v)
{
  
  dimT = dim(T)
  
  a_tau = matrix(0,L,dimT[1])
  b_tau = matrix(0,L,dimT[2])
  c_tau = matrix(0,L,dimT[3])
  w_tau = rep(0,L)
  
  a_hat = matrix(0,K,dimT[1])
  b_hat = matrix(0,K,dimT[2])
  c_hat = matrix(0,K,dimT[3])
  w_hat = rep(0,K)
  
  
  for(tau in 1:L)
  {
      a =  as.matrix(rnorm(dimT[1])) 
      a = a/norm(a,"F")       
      b =  as.matrix(rnorm(dimT[2]) )
      b = b/norm(b,"F")       
      c =  as.matrix(rnorm(dimT[3]))
      c = c/norm(c,"F")    
    

       a_prev = a 
       b_prev = b        
       c_prev = c 
       
       ################
       for(t in 1:N)
       {
            a =  matrix(product(T,c(2,3),b_prev,c_prev,a_prev),1,dimT[1])
            a = a/norm(a,"F")
            b =  matrix(product(T,c(1,3),a_prev,c_prev,b_prev),1,dimT[2])
            b = b/norm(b,"F")            
            c =  matrix(product(T,c(1,2),a_prev,b_prev,c_prev),1,dimT[3])
            c = c/norm(c,"F")
            
            a_prev = as.vector(a)
            b_prev = as.vector(b) 
            c_prev = as.vector(c)            
       }
       w_tau[tau] = product(T,c(1,2,3),as.vector(a),as.vector(b),as.vector(c))
       a_tau[tau,] = as.vector(a)
       b_tau[tau,] = as.vector(b)
       c_tau[tau,] = as.vector(c)      
  }
  
  ########## cluster
  indexes = 1:L
  
  for(i in 1:K) 
  {
     if(length(indexes)==0)
     {
       return(list( a_hat = a_hat, b_hat = b_hat,c_hat =c_hat  ))  
     }
     
    
      ind = which( abs(w_tau[indexes]) == max(abs(w_tau[indexes])) )
    
       
      a = a_tau[ indexes[ind],]
      b = b_tau[ indexes[ind],]  
      c = c_tau[ indexes[ind],]
            
      a_prev = a 
      b_prev = b        
      c_prev = c      
      
      for(t in 1:N)
      {
        a =  matrix(product(T,c(2,3),b_prev,c_prev,a_prev),1,dimT[1])
        a = a/norm(a,"F")
        b =  matrix(product(T,c(1,3),a_prev,c_prev,b_prev),1,dimT[2])
        b = b/norm(b,"F")            
        c =  matrix(product(T,c(1,2),a_prev,b_prev,c_prev),1,dimT[3])
        c = c/norm(c,"F")
        
        a_prev = as.vector(a)
        b_prev = as.vector(b) 
        c_prev = as.vector(c)        
      }
      
      a_hat[i,] = as.vector(a)
      b_hat[i,] = as.vector(b)
      c_hat[i,] = as.vector(c)
      
      
      
      length_indexes = length(indexes)
      remove_indexes = c()
       
      
      if(length_indexes  == 0)
      {
        return(list( a_hat = a_hat, b_hat = b_hat,c_hat =c_hat  ))
      }
      
      for(j in 1:length_indexes)
      {
         aux = max(c( abs(sum(a_hat[i,]*a_tau[indexes[j],])), abs(sum(b_hat[i,]*b_tau[indexes[j],])), abs(sum(c_hat[i,]*c_tau[indexes[j],])) ))
             
         if(aux > par_v)
         {
           remove_indexes = c(  remove_indexes, j)   
         }
       #  print(aux)
      }
      remove_indexes  = c(remove_indexes ,indexes[ind])
      indexes = setdiff(indexes, remove_indexes )
  }###close loop for k

  
  return(list( a_hat = a_hat, b_hat = b_hat,c_hat =c_hat  ))  
}### close function


################################333333

##############################################3


svd_initals  = function(X)
{
   u =  matrix(rnorm(dim(X)[1]),1,dim(X)[1] )
   u = u/norm(u,"F")
   
     lizt <- list('mat' = u)
     aux =   ttl(X, lizt, ms = 1)
  
     aux = matrix(aux@data,dim(X)[2],dim(X)[3])
     
     aux = svd(aux)
     v = aux$u[,1]
     w = aux$v[,1]
     
     u = product(X,c(2,3),v,w,u)
     u = u/sum(u^2)
 
     return( list(u = u,v =v ,w =w ))      
}
##############################################3##############################################3
##############################################3##############################################3
##############################################3##############################################3
##############################################3##############################################3
##############################################3##############################################3




multiple_factors= function(X,K,a_init,b_init,c_init,c1,c2,c3,Niter,kv,kw)
{

  w_hat = rep(0,K)
  
  for(j in 1:K)
  {
    w_hat[j] = product(X,c(1,2,3), a_init[j,],b_init[j,],c_init[j,]  ) 
  }
  Y = as.tensor(array(0,dim(X)))
  
  obj_value_prev =  fnorm(Y - X)
  
  for( j in 1:K)
  {
    lizt <- list('mat' = as.matrix(a_init[j,]),'mat2' = as.matrix(b_init[j,]),'mat3'= as.matrix(c_init[j,]) )
    aux =   ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    Y = Y + w_hat[j]*aux 
  }##  closing for j
  
  ##################333
  c1_star =  rep(0,K)
  c2_star =  rep(0,K)
  c3_star =  rep(0,K)  
  ######
  
  for(iter in 1:Niter)
  {  
    for(j in 1:K)
    {
      lizt <- list('mat' = as.matrix(a_init[j,]),'mat2' = as.matrix(b_init[j,]),'mat3'= as.matrix(c_init[j,]) )
      aux =   ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
      
      Y  = Y -  w_hat[j]*aux 
      ##############################################
      
      
      #     temp2 = PTD_L1AB_unconstrained(X-Y,Av,Aw,c1[j],c2[j],c3[j],.1,1)
      Z =  X-Y   
      
      # if(iter==1)
      # {
      temp2 = PTD_L1AB_unconstrained(Z,Av,Aw,c1,c2,c3,1,kv,kw)
      c1_star[j] = temp2$c1
      c2_star[j] = temp2$c2 
      c3_star[j] = temp2$c3

      
      
      ##############################################
      a_init[j,] = as.vector(temp2$u)
      b_init[j,] = as.vector(temp2$v)      
      c_init[j,] = as.vector(temp2$w)
      w_hat[j] = product(Z,c(1,2,3), a_init[j,],b_init[j,],c_init[j,]  )
      

      lizt <- list('mat' = as.matrix(a_init[j,]),'mat2' = as.matrix(b_init[j,]),'mat3'= as.matrix(c_init[j,]) )
      aux =   ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
      
      
      Y = Y + w_hat[j]*aux 
      
    }
    
    obj_value =  fnorm(Y - X)
    
    if((obj_value - obj_value_prev)/(obj_value_prev +.00001)<.001)
    {break;}
    
    obj_value_prev = obj_value
    
  }## close loop for iter
  
  return(list(a_hat = a_init,b_hat = b_init,c_hat = c_init,w_hat = w_hat,c1_star = c1_star,c2_star = c2_star,c3_star= c3_star))
}###  close

#################################################################3
######################################################################
###################################################################




PTD_no_penalties <- function(Z,A,B,c1,c2,c3,Epsilon,Niter,  kv,kw ) 
{
  
  #  trendfilter(y, x, weights, k = 2L, family = c("gaussian", "logistic",
  "poisson"#), method = c("admm"), lambda, nlambda = 50L,
  #             lambda.min.ratio = 1e-05, thinning = NULL, verbose = FALSE,
  #              control = trendfilter.control.list())
  # initials
  #  PTDL1L1L1  =   PTD_L1L1L1(Z,sqrt(dim(Z)[1]),sqrt(dim(Z)[2]),sqrt(dim(Z)[3]),epsilon,5) 
  u = inits(dim(Z)[1])
  v = inits(dim(Z)[2])
  w = inits(dim(Z)[3])
  
  for(j in 1:10)
  {
    lizt <- list('mat2' = v,'mat3' =w)
    u =   ttl(Z, lizt, ms = c(2,3)) 
    u = t(as.matrix(u@data))
    u =  u/norm(u,"F")
    
    lizt <- list('mat2' = u,'mat3' =w)
    v =   ttl(Z, lizt, ms = c(1,3)) 
    v = t(as.matrix(v@data))
    v =  v/norm(v,"F")
    
    lizt <- list('mat2' = u,'mat3' =v)
    w =   ttl(Z, lizt, ms = c(1,2)) 
    w = t(as.matrix(w@data))
    w =  w/norm(w,"F")
  }
  
  
  
  
  lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
  d = ttl(Z, lizt, ms = c(1,2,3))  
  
  
  return(list(u = u, v= v, w=w,d=d)) 
}

##############################################3##############################################3
##############################################3##############################################3
##############################################3##############################################3




simple_factor_model = function(T,K,a_init,b_init,c_init,c1,c2,c3,Niter,kv,kw)
{
  
  w_hat = rep(0,K)
  
  for(j in 1:K)
  {
    w_hat[j] = product(X,c(1,2,3), a_init[j,],b_init[j,],c_init[j,]  ) 
  }
  Y = as.tensor(array(0,dim(X)))
  
  for( j in 1:K)
  {
    lizt <- list('mat' = as.matrix(a_init[j,]),'mat2' = as.matrix(b_init[j,]),'mat3'= as.matrix(c_init[j,]) )
    aux =   ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
    
    Y = Y + w_hat[j]*aux 
  }##  closing for j
  
  ##################333
  c1_star =  rep(0,K)
  c2_star =  rep(0,K)
  c3_star =  rep(0,K)  
  ######
  
  for(iter in 1:Niter)
  {  
    for(j in 1:K)
    {
      lizt <- list('mat' = as.matrix(a_init[j,]),'mat2' = as.matrix(b_init[j,]),'mat3'= as.matrix(c_init[j,]) )
      aux =   ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
      
      Y  = Y -  w_hat[j]*aux 
      ##############################################
      
      
      #     temp2 = PTD_L1AB_unconstrained(X-Y,Av,Aw,c1[j],c2[j],c3[j],.1,1)
      Z =  T-Y   
      
      # if(iter==1)
      # {
      temp2 = PTD_no_penalties(Z,Av,Aw,c1,c2,c3,.1,1,kv,kw)
    #  c1_star[j] = temp2$c1
    #  c2_star[j] = temp2$c2 
    #  c3_star[j] = temp2$c3
      #  }
      #  if(iter > 1)
      # {
      #    temp2 = PTD_L1AB_unconstrained(Z,Av,Aw,c1_star[j],c2_star[j],c3_star[j],.1,1,kv,kw)
      # }
      
      
      ##############################################
      a_init[j,] = as.vector(temp2$u)
      b_init[j,] = as.vector(temp2$v)      
      c_init[j,] = as.vector(temp2$w)
      w_hat[j] = product(Z,c(1,2,3), a_init[j,],b_init[j,],c_init[j,]  )
      
      #        for(i in 1:K)
      #        {
      #           if(i != j)
      #           {
      #             w_hat[j] = w_hat[j] -  w_hat[i]*sum(a_init[j,]*a_init[i,])*sum(b_init[j,]*b_init[i,])*sum(c_init[j,]*c_init[i,])
      #           }
      #        }
      #      
      lizt <- list('mat' = as.matrix(a_init[j,]),'mat2' = as.matrix(b_init[j,]),'mat3'= as.matrix(c_init[j,]) )
      aux =   ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
      
      
      Y = Y + w_hat[j]*aux 
      
    }
  }## close loop for iter
  
  return(list(a_hat = a_init,b_hat = b_init,c_hat = c_init,w_hat = w_hat))
}###  close


###############################################
###########################################################################
############################################################################################


