rm(list = ls())

###  R code to run the simulated experiments for tables 1 and 2 of the main paper
### This is supported by the following R packages:

##  R package Matrix:
##  Douglas Bates and Martin Maechler. Matrix: Sparse and Dense Matrix Classes and Methods. 2005. R package version 1.2-2.
##  Available at: http://CRAN.R-project.org/package=Matrix

##  R package glmgen:
##  Taylor Arnold and Veeranjaneyulu Sadhanala and Ryan Tibshirani. glmgen: Fast algorithms for generalized lasso problems. 2014. R package version 0.0.3.
##  Available at: https://github.com/statsmaths/glmgen


## Rpackage genlasso:
## Taylor B. Arnold and Ryan J. Tibshirani. genlasso: Path algorithm for generalized lasso problems. 2014. 
## available at: http://CRAN.R-project.org/package=genlasso

## Rpackage rTensor:
## James Li and Jacob Bien and Martin Wells. rTensor: Tools for tensor analysis and decomposition. 2014. R package version 1.2.
## available at: http://CRAN.R-project.org/package=rTensor



## workind directory with all the files
setwd("/Users/user/Documents/tensors/tex/jcgs-template/Final_version/code")

library(Matrix)
library(rTensor)
library(genlasso)
source("cross_validation.R")
source("create_structures.R")
source("utilities.R")
library(glmgen)


#library(foreach)
#library(doSNOW)

temp =  create_structures()
###  True vectors

## Different combinations of vectors giving rise to different structures
# each structure is obtained by taking the outer product of the involved vectors
u_generative = temp$u_generative 
v_generative = temp$v_generative 
w_generative = temp$w_generative   

i = 1
#plot(u_generative[i,1:10] )
plot(v_generative[i,1:1000] )
#plot(w_generative[i,1:400] )
# 
c1_L1 = seq(1,sqrt(ncol(u_generative)),len=5)   ##  tuning parameters for first mode, constrained version of L1
c2_L1 = seq(1,sqrt(ncol(v_generative)),len=5)  ##  tuning parameters for second mode, constrained versions  of L1
c3_L1 = seq(1,sqrt(ncol(w_generative)),len=5) ##  tuning parameters for  secon mode, constrained versions  of L1

c2 =  c(1,5,10,20, 50,100) ##  tunning parameters for unconstrained genaralized lasso penalties
c3 =  c(1,5,10,20, 50,100) ## tunning parameters for unconstrained genaralized lasso penalties
#c1 =  c(1,5,10,100)

c2_L1_unconstrained = c(0,.1,1,5,100,1000) ##  tuning parameters for second mode, unconstrained version of L1
c3_L1_unconstrained  = c(0,.1,1,5,100,1000) ##  tuning parameters for tird mode, unconstrained version of L1
c1_L1_unconstrained  = c(0,.1,1,5,100,1000) ##  tuning parameters for first mode, unconstrained version of L1


c2_PMDL1 =    c(0,.1,1:8,50,100,1000) # tunning parameters for PMD with unconstrained L1
c3_PMDL1 =  c(0,.1,1:8,50,100,1000)  # tunning parameters for PMD with unconstrained L1

#Epsilon = 0.01     


################


Num_trials = 100

## rank1 expriments with varying noise
## This corresponds to Table 2 in the paper
## the function table1 can be found in the fule "utilities.R"
experiment2 = table3(u_generative,v_generative,w_generative, c1_L1,c2_L1,c3_L1,c2,c3,c1_L1_unconstrained,c1_L2_unconstrained,c3_L1_unconstrained,c2_PMDL1 ,c3_PMDL1,Num_trials )


Table2 =  matrix(0,dim(experiment2)[1],dim(experiment2)[3])

for(i in 1:dim(Table2)[1])
{
  for(j in 1:dim(Table2)[2])
  {
     Table2[i,j] =  mean(experiment2[i,,j])
  }
}
# The columns of Table2 represent different structures: structure 1,  structure 2,  structure 3,  structure 4,  structure 5
# The variance of the noise is set to be 1
# The rows of Table2 represent different methods, as in the paper: PTD(L1,L1,L1), PTD(L1,FL,FL), PTD(L1,TF1,FL), PTD(L1,TF1,TF1),
# PMD(L1,L1), PMD(FL,FL), PMD(L1,FL)
# Each entry  Table2[i,j] is the frobenius norm estimation error of the method i for sturcture j
print(Table2)

##############################################################################################################
## rank1 exprimentsfor different structures, the function table1 can be found in the fule "utilities.R"
experiment1  = table1(u_generative,v_generative,w_generative, c1_L1,c2_L1,c3_L1,c2,c3,c1_L1_unconstrained,c1_L2_unconstrained,c3_L1_unconstrained,c2_PMDL1 ,c3_PMDL1,Num_trials)

Table1 =  matrix(0,dim(experiment1)[1],dim(experiment1)[3])

for(i in 1:dim(Table1)[1])
{
  for(j in 1:dim(Table1)[2])
  {
    Table1[i,j] =  mean(experiment1[i,,j])
  }
}
# The columns of Table1 represent different levels of the variance noise \sigma =  1.25,1.5,1.75,2,2.25.  
# The rows of Table1 represent different methods, as in the paper: PTD(L1,L1,L1), PTD(L1,FL,FL), PTD(L1,TF1,FL), PTD(L1,TF1,TF1),
# PMD(L1,L1), PMD(FL,FL), PMD(L1,FL)
# Each entry  Table1[i,j] is the frobenius norm estimation error of the method i for the j-th variance when
# recovering structure  2.
print(Table1)

## visuzaling the structures
font_size = 1.5
font_size2 = 1.5
pdf("new_tensors4.pdf",height = 4.5,width = 7) #, width = 8, height = 5
par(mfrow=c(5,3),oma=c(1,1,1,1), mar=c(2,2,2,2))
plot(u_generative[1,],xlab = "index",ylab = "", main = "True u",ylim = c(-1.5,1.5),cex.lab = font_size2, cex.main = font_size)
plot(v_generative[1,],xlab = "index", ylab = "",main = "True v",ylim = c(-0.5,1.5),cex.lab = font_size2, cex.main = font_size)
plot(w_generative[1,],xlab = "index", ylab = "",main = "True w",ylim = c(-1.5,1.5),cex.lab = font_size2, cex.main = font_size)

plot(u_generative[2,],xlab = "index",ylab = "", main = "",ylim = c(-1.5,.5),cex.lab = font_size2)
plot(v_generative[2,],xlab = "index", ylab = "",main = "",ylim = c(-1.5,1.5),cex.lab = font_size2)
plot(w_generative[2,],xlab = "index", ylab = "",main = "",ylim = c(-1.5,1.5),cex.lab = font_size2)

plot(u_generative[3,],xlab = "index",ylab = "", main = "",ylim = c(-1.5,1.5),cex.lab = font_size2)
plot(v_generative[3,],xlab = "index", ylab = "",main = "",ylim = c(-.5,2),cex.lab = font_size2)
plot(w_generative[3,],xlab = "index", ylab = "",main = "",ylim = c(-.5,1.5),cex.lab = font_size2)

plot(u_generative[4,],xlab = "index",ylab = "", main = "",ylim = c(-.5,1.5),cex.lab = font_size2)
plot(v_generative[4,],xlab = "index", ylab = "",main = "",ylim = c(-1,2),cex.lab = font_size2)
plot(w_generative[4,],xlab = "index", ylab = "",main = "",ylim = c(-.5,1.5),cex.lab = font_size2)


plot(u_generative[5,],xlab = "index",ylab = "", main = "",ylim = c(-1.5,1.5),cex.lab = font_size2)
plot(v_generative[5,],xlab = "index", ylab = "",main = "",ylim = c(-2.8,3),cex.lab = font_size2)
plot(w_generative[5,],xlab = "index", ylab = "",main = "",ylim = c(-2,2.5),cex.lab = font_size2)
dev.off()

