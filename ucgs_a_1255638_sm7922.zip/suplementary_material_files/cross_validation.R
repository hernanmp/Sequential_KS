


### This is supported by the following R packages:

##  R package Matrix:
##  Douglas Bates and Martin Maechler. Matrix: Sparse and Dense Matrix Classes and Methods. 2005. R package version 1.2-2.
##  Available at: http://CRAN.R-project.org/package=Matrix

##  R package glmgen:
##  Taylor Arnold and Veeranjaneyulu Sadhanala and Ryan Tibshirani. glmgen: Fast algorithms for generalized lasso problems. 2014. R package version 0.0.3.
##  Available at: https://github.com/statsmaths/glmgen


## Rpackage genlasso:
## Taylor B. Arnold and Ryan J. Tibshirani. genlasso: Path algorithm for generalized lasso problems. 2014. 
## available at: http://CRAN.R-project.org/package=genlasso

## Rpackage rTensor:
## James Li and Jacob Bien and Martin Wells. rTensor: Tools for tensor analysis and decomposition. 2014. R package version 1.2.
## available at: http://CRAN.R-project.org/package=rTensor


## Xlocations is a tensor with one in a location where an entry of X was deleted a zero otherwise
Generate_data <- function(u_generative,v_generative,w_generative,sigma)
{
  ####  Generate raw data
  X = array( sigma*rnorm(length(u_generative)*length(v_generative)*length(w_generative)) ,c(length(u_generative),length(v_generative),length(w_generative))) 

  
  X =   as.tensor(X, drop = FALSE)
  
  
  lizt <- list('mat' = as.matrix(u_generative),'mat2' = as.matrix(v_generative),'mat3'= as.matrix(w_generative) )
  true = ttl(as.tensor(array(1,c(1,1,1))), lizt, ms = c(1,2,3))
  X =  X + true
  
  
  ###################### ###################### ######################
  ###  Generate training data and save locations of deleted data
  
  
  X_tilde = X@data
  X_aux = array(0, dim(X)) 
  
  for(i in 1:length(u_generative))
  {
    for(j in 1:length(v_generative))
    {
      for(k in  1:length(w_generative))
      {
        coin = rbinom(1,1,0.1)
        
        if(coin == 1)
        { 
          X_tilde[i,j,k] = 0
          X_aux[i,j,k] = 1
        }   
      } 
    }
  }  
  X_tilde = as.tensor(X_tilde, drop = FALSE)
  X_aux = as.tensor(X_aux, drop = FALSE)
  
  return(list(X_raw = X,  X_training= X_tilde, X_locations = X_aux)) 
  
}

###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################


PTD_L1L1L1   <- function(Z,c1,c2,c3,Niter) 
{
  u = inits(dim(Z)[1])
  v = inits(dim(Z)[2])
  w = inits(dim(Z)[3])
  
  u = u/ sqrt(sum(u*u))   
  v = v/ sqrt(sum(v*v))
  w = w/ sqrt(sum(w*w))
  
  
  for(j in 1:5)
  {
    lizt <- list('mat2' = v,'mat3' =w)
    u =   ttl(Z, lizt, ms = c(2,3)) 
    u = t(as.matrix(u@data))
    u =  u/norm(u,"F")
    
    lizt <- list('mat2' = u,'mat3' =w)
    v =   ttl(Z, lizt, ms = c(1,3)) 
    v = t(as.matrix(v@data))
    v =  v/norm(v,"F")
    
    lizt <- list('mat2' = u,'mat3' =v)
    w =   ttl(Z, lizt, ms = c(1,2)) 
    w = t(as.matrix(w@data))
    w =  w/norm(w,"F")
  }
  
  
  
  
  u_prev = u; v_prev = v; w_prev =w;
  
  lizt <- list('mat1' =u_prev,'mat2' = v_prev,'mat3' =w_prev)
  fprev =  ttl(Z, lizt, ms = c(1,2,3)) 
  
  fprev = fprev@data 
  
  for( iter in 1:Niter)
  {
    w = t(as.matrix(L1_update_unconstrained(Z,u,v,c3,3))) 
    if(length(which(w!=0))==0)
    {   iter = 42; break}
    
    u =  t(as.matrix(L1_update_unconstrained(Z,v,w,c1,1))) 
    if(length(which(u!=0))==0)
    {   iter = 42; break}
    
    # v =  GenLasso_update(Z,u,w,c2,A,2)
    v = t(as.matrix(L1_update_unconstrained(Z,u,w,c2,2)))
    if(length(which(v!=0))==0)
    {   iter = 42; break}
    
    
    lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
    f =  ttl(Z, lizt, ms = c(1,2,3)) 
    f = f@data 
    
    aux = abs((f-fprev)/(fprev+ 0.0001))
    
    
    if( aux< 0.00001)
    { break}
    
    
    fprev = f
    u_prev = u; v_prev = v; w_prev =w;
  }
  # print(aux)  
  u = t(as.matrix(as.vector(u)))
  v = t(as.matrix( as.vector(v)  ))
  w = t(as.matrix( as.vector(w) ))
  
  lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
  d = ttl(Z, lizt, ms = c(1,2,3))  
  
  return(list(iter = iter, u = u, v= v, w=w,d= d)) 
}

###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################



cv_PTD_L1L1L1 <- function(Z,Z_training,Z_locations,c1,c2,c3)
{
  
  MSE = Inf
  
  for (i in 1:length(c1))
  {
    for(j in 1:length(c2))
    {

      for(k in 1:length(c3))
      {
        
        #print(k)
        
        #(Z,c1,c2,c3,Epsilon)
        PTD = PTD_L1L1L1(Z_training,c1[i],c2[j],c3[k],5)   
        
        
        iter = PTD$iter           
        
        if(iter < 42)
        {
          u = PTD$u
          v = PTD$v
          w = PTD$w 
          
          
          lizt <- list('mat1' =u,'mat2' = v,'mat3' =w)
          g = ttl(Z_training, lizt, ms = c(1,2,3))
          
          
          lizt <- list('mat1' =t(u),'mat2' = t(v),'mat3' =t(w))
          
          aux = Z_locations*ttl(g, lizt, ms = c(1,2,3))
          X_aux2 = Z_locations * Z
          aux =  fnorm(aux-X_aux2)
          
          if(  MSE > aux) 
          {
            MSE =  aux
            i_star =i; j_star =j;k_star =k;
          }
          #     print(MSE)
        }
        
      }    
    }        
  }
  
  return(list(i = i_star, j = j_star, k =k_star))
}


###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################



table1 <- function(u_generative,v_generative,w_generative, c1_L1,c2_L1,c3_L1,c2,c3,c1_L1_unconstrained,c1_L2_unconstrained,c3_L1_unconstrained,c2_PMDL1 ,c3_PMDL1,Num_trials)
{
#  Num_trials = 100
  Num_data_sets = nrow(u_generative) 
  Num_penalties = 7
  distance_error = array(0, c(Num_penalties,Num_trials,Num_data_sets))

  ## cv_indicator
  cv_indicator = 0 
  ## if cv_indicator  = 0 then the parameters will only be estimated at the first iteration and used 
  ## with the same value there after
  ##  if cv_indicator = 1, the the code will estimate the parameters at every trial, this can take several days, not
  ## recommended, you might need parallel computing to gain speed


 for(s in 1: 5)
 {
  print(s)
  
  for(iter in 1: Num_trials)
  {
    ## Generating data 
    print(iter)
    lizt <- list('mat1' =(as.matrix(u_generative[s,])),'mat2' = as.matrix(v_generative[s,]),'mat3' = as.matrix(w_generative[s,]))
    aux =   array(1,c(1,1,1))
    aux = as.tensor(aux,drop= FALSE)
    true = ttl(aux, lizt, ms = c(1,2,3))
    
    
    dat =   Generate_data(u_generative[s,],v_generative[s,],w_generative[s,],1) 
    X_observed =  dat$X_raw
    X_training = dat$X_training
    X_locations = dat$X_locations 
    
    
    #################################################
    ## L1L1L1
    if(iter == 1  ||  cv_indicator == 1)
    {
      indexesL1L1L1_t1 = cv_PTD_L1L1L1(X_observed,X_training,X_locations,c1_L1_unconstrained,c2_L1_unconstrained,c3_L1_unconstrained)
      i  = indexesL1L1L1_t1$i  
      j  = indexesL1L1L1_t1$j
      k  = indexesL1L1L1_t1$k
      
      i_L1L1L1 = i
      j_L1L1L1 = j
      k_L1L1L1 = k    
    }
    
     PTDL1L1L1_t1 = PTD_L1L1L1(X_observed,c1_L1_unconstrained[i_L1L1L1],c2_L1_unconstrained[j_L1L1L1],c3_L1_unconstrained[k_L1L1L1],20)
    
    distance_error[1,iter,s] = tensor_distance(PTDL1L1L1_t1$d,PTDL1L1L1_t1$u,PTDL1L1L1_t1$v,PTDL1L1L1_t1$w,true) 
  
    
    print("L1L1L1")
    print(distance_error[1,iter,s])
    
    #################################################
    ## L1 FL FL 
    Av = fussed_lasso(length(v_generative[s,]))
    Aw = fussed_lasso(length(w_generative[s,]))
    kv = 0
    kw = 0
    
    if(iter == 1 ||  cv_indicator == 1)
    {
      indexesFLFL_t1 = cv_PTD_L1AB_unconstrained(X_observed,X_training,X_locations,Av,Aw,c1_L1,c2,c3,kv,kw)
      i1  = indexesFLFL_t1$i  
      j1  = indexesFLFL_t1$j
      k1 = indexesFLFL_t1$k
      
      i_L1FLFL = i1
      j_L1FLFL = j1
      k_L1FLFL = k1    
    }
    
    PTDFLFL_t1 = PTD_L1AB_unconstrained_2(X_observed,Av,Aw,c1_L1[i_L1FLFL],c2[j_L1FLFL ],c3[k_L1FLFL],20,kv,kw)
    distance_error[2,iter,s] = tensor_distance(PTDFLFL_t1$d,PTDFLFL_t1$u,PTDFLFL_t1$v,PTDFLFL_t1$w,true)

    print("L1FLFLL")
    print(distance_error[2,iter,s])
    
    #################################################
    ## L1 TF FL
    Av = trend_filtering(1,length(v_generative[s,]))
    kv = 1
    
    if(iter == 1 ||  cv_indicator == 1)
    {
      indexesPTDTFFL_t1 = cv_PTD_L1AB_unconstrained(X_observed,X_training,X_locations,Av,Aw,c1_L1,c2,c3,kv,kw)
      i  = indexesPTDTFFL_t1$i  
      j  = indexesPTDTFFL_t1$j
      k = indexesPTDTFFL_t1$k
      
      i_L1TFFL = i
      j_L1TFFL = j
      k_L1TFFL = k  
      
    }

    
    PTDTFFL_t1 = PTD_L1AB_unconstrained_2(X_observed,Av,Aw,c1_L1[i_L1TFFL],c2[j_L1TFFL],c3[k_L1TFFL],20,kv,kw)
    
    distance_error[3,iter,s] = tensor_distance(PTDTFFL_t1$d,PTDTFFL_t1$u,PTDTFFL_t1$v,PTDTFFL_t1$w,true)

    print("L1FLTF")
    print(distance_error[3,iter,s])
    
    #################################################
    ## L1 TF TF
    Av = trend_filtering(1,length(v_generative[s,]))
    Aw = trend_filtering(1,length(w_generative[s,]))
    kv = 1
    kw = 1
    
    
    if(iter == 1 ||  cv_indicator == 1 )
    {
    indexesPTDTFTF_t1 = cv_PTD_L1AB_unconstrained(X_observed,X_training,X_locations,Av,Aw,c1_L1,c2,c3,kv,kw)
    i_L1TFTF  = indexesPTDTFTF_t1$i 
    j_L1TFTF   = indexesPTDTFTF_t1$j
    k_L1TFTF  = indexesPTDTFTF_t1$k
    }
    PTDTFTF_t1 = PTD_L1AB_unconstrained_2(X_observed,Av,Aw,c1_L1[i_L1TFTF ],c2[j_L1TFTF ],c3[k_L1TFTF ],20,kv,kw)
    
    distance_error[4,iter,s] = tensor_distance(PTDTFTF_t1$d,PTDTFTF_t1$u,PTDTFTF_t1$v,PTDTFTF_t1$w,true)
    print("L1TFTF")
    print(distance_error[4,iter,s])
    
    #################################################
    ## PMD L1L1L1
    if(iter == 1 ||  cv_indicator == 1)
    {

      Z =  X_observed@data
      Z_training = X_training@data
      Z_locations = X_locations@data 
      dim = dim(X_observed)
      v_L1L1 =   matrix(0,dim[1],dim[2])
      w_L1L1 =   matrix(0,dim[1],dim[3])
      par_L1L1 =  matrix(0,dim[1],2)
      
      for( i in  1:dim(X_observed)[1])
      {
        out= cv_PMD_T_L1L1(Z[i,,],Z_training[i,,],Z_locations[i,,],c2_PMDL1,c3_PMDL1) 
        
        v_L1L1[i,] = as.vector(out$u)
        w_L1L1[i,] = as.vector(out$v)
        par_L1L1[i,1] = out$j
        par_L1L1[i,2] = out$k  
      }
    }
    
    estimatedPMDL1L1  = array(0, dim(Z)) 

    
    for( i in  1:dim(X_observed)[1])
    {

      out = PMD_L1L1(Z[i,,],c2_PMDL1[par_L1L1[i,1]],c3_PMDL1[par_L1L1[i,2]],20) 
      
      v_L1L1[i,] = as.vector(out$u)
      w_L1L1[i,] = as.vector(out$v)
      
      aux = as.matrix(v_L1L1[i,]) %*% t(as.matrix(w_L1L1[i,]))
      d = t( as.matrix(v_L1L1[i,]) ) %*% Z[i,,] %*% as.matrix(w_L1L1[i,])
      estimatedPMDL1L1[i,,] = as.numeric(d) * aux
    }

    
    distance_error[5,iter,s]  = fnorm(as.tensor(estimatedPMDL1L1,drop=FALSE)-true) 

    print("PMD_L1L1")
    print(distance_error[5,iter,s])
    

    #################################################
    ## PMD FLFL
    if(iter == 1 ||  cv_indicator == 1)
    {
      v_FLFL =   matrix(0,dim[1],dim[2])
      w_FLFL =   matrix(0,dim[1],dim[3])
      par_FLFL =  matrix(0,dim[1],2)
      
      for( i in  1:dim(X_observed)[1])
      {
        out= cv_PMD_T_FLFL(Z[i,,],Z_training[i,,],Z_locations[i,,],c2,c3) 
        
        v_FLFL[i,] = as.vector(out$u)
        w_FLFL[i,] = as.vector(out$v)
        par_FLFL[i,1] = out$j
        par_FLFL[i,2] = out$k      
      }
    }
   
    
    estimatedPMDFLFL  = array(0, dim(Z)) 

 
    for( i in  1:dim(X_observed)[1])
    {
      out=  PTD_FLFL(Z[i,,],c2[par_FLFL[i,1]],c3[par_FLFL[i,2]],Av,Aw,10) 
      
      v_FLFL[i,] = as.vector(out$u)
      w_FLFL[i,] = as.vector(out$v)
      
      aux = as.matrix(v_FLFL[i,]) %*% t(as.matrix(w_FLFL[i,]))
      d = t( as.matrix(v_FLFL[i,]) ) %*% Z[i,,] %*% as.matrix(w_FLFL[i,])
      estimatedPMDFLFL[i,,] = as.numeric(d) * aux
    }
 
    
    
    estimatedFLFL = as.tensor(estimatedPMDFLFL, drop = FALSE)
    distance_error[6,iter,s]  = fnorm(estimatedFLFL -true) 

    print("PMD_FLFL")
    print(distance_error[6,iter,s])
    
    
    if(iter == 1 ||  cv_indicator == 1)
    {
      v_FLL1 =   matrix(0,dim[1],dim[2])
      w_FLL1 =   matrix(0,dim[1],dim[3])
      par_FLL1 =  matrix(0,dim[1],2)
      
      for( i in  1:dim(X_observed)[1])
      {
        out= cv_PMD_T_FLL1(Z[i,,],Z_training[i,,],Z_locations[i,,],c2,c3_PMDL1) 
        
        v_FLL1[i,] = as.vector(out$u)
        w_FLL1[i,] = as.vector(out$v)
        par_FLL1[i,1] = out$j
        par_FLL1[i,2] = out$k      
      }
    }
    
    estimatedPMDFLL1  = array(0, dim(Z)) 

    for( i in  1:dim(X_observed)[1])
    {
      out= PMD_FLL1(Z[i,,],c2[par_FLL1[i,1]],c3_PMDL1[par_FLL1[i,2]],Av,10) 
      
      v_FLL1[i,] = as.vector(out$u)
      w_FLL1[i,] = as.vector(out$v)
      
      aux = as.matrix(v_FLL1[i,]) %*% t(as.matrix(w_FLL1[i,]))
      d = t( as.matrix(v_FLL1[i,]) ) %*% Z[i,,] %*% as.matrix(w_FLL1[i,])
      estimatedPMDFLL1[i,,] = as.numeric(d) * aux
    }

    estimatedFLL1 = as.tensor(estimatedPMDFLL1, drop = FALSE)
    distance_error[7,iter,s]  = fnorm(estimatedFLL1 -true) 

    
    print("PMD_FLL1")
    print(distance_error[7,iter,s])
  } # close for iter
 }## close for i 
  
  return(distance_error)
}

###############################################################################################
# ###############################################################################################

###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################

tensor_distance <- function(d,u,v,w,true)
{
  
  lizt <- list('mat1' =t(u),'mat2' = t(v),'mat3' =t(w))
  aux = ttl(d, lizt, ms = c(1,2,3))
  
  return(fnorm(true-aux))
  
}
###############################################################################################
###############################################################################################
###############################################################################################


fussed_lasso <- function(m)
{
  B = matrix(0,m-1,m)
  
  B[1,1] = -1
  B[1,2] = 1
  
  for(i in 2:(m-1))
  {
    B[i,i] = -1
    B[i,i+1] = 1
  }
  
  
  regMat = B
  
  library(Matrix)
  
  B <- as(regMat, "sparseMatrix")  
}
## m is the length to which is applied
## k is the order of trend filtering
trend_filtering <- function(k,m)                        
{
  A = matrix(0,m-2,m)  
  
  A[1,1] = -1
  A[1,2] = 2
  A[1,3] = -1
  
  for(i in 2:(m-2))
  {
    A[i,i] = -1
    A[i,i+1] = 2
    A[i,i+2] = -1
  }
  
  regMat = A
  
  library(Matrix)
  
  A <- as(regMat, "sparseMatrix")       # see also `vignette("Intro2Matrix")`      
  ###############################    
  if(k> 1)
  {  
    D1 = matrix(0,m-3,m-2)  
    
    D1[1,1] = -1
    D1[1,2] = 1
    
    
    for(i in 2:(m-3))
    {
      D1[i,i] = -1
      D1[i,i+1] = 1
    }
    
    
    regMat = D1
    
    library(Matrix)
    
    D1 <- as(regMat, "sparseMatrix")       
    A =  D1 %*% A 
    
  }
  if(k>2)
  {
    D1 = matrix(0,m-4,m-3)  
    
    D1[1,1] = -1
    D1[1,2] = 1
    
    
    for(i in 2:(m-4))
    {
      D1[i,i] = -1
      D1[i,i+1] = 1
    }
    
    
    regMat = D1
    
    library(Matrix)
    
    D1 <- as(regMat, "sparseMatrix")       
    A =  D1 %*% A 
    
  }
  
  return(A)
}   

###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################


cvPMD <- function(Z,c1,c2,c3) 
{
  
  dim = dim(Z)
  
  estimated = array(0, dim(Z)) 
  Z =  Z@data
  
  v =   matrix(0,dim[1],dim[2])
  w =   matrix(0,dim[1],dim[3])
  
  for( i in  1:dim[1])
  {
    
    cv.out <- PMD.cv(Z[i,,],type="ordered",sumabsus=seq(1, sqrt(dim[2]), len=10),trace = FALSE)
    out <- PMD(Z[i,,],type="ordered",
               sumabsu=cv.out$bestsumabsu,niter=20,K=1,v=cv.out$v.init)
    
    v[i,] = out$u[,1]
    w[i,] = out$v[,1]
    
    aux = as.matrix(v[i,]) %*% t(as.matrix(w[i,]))
    d = t( as.matrix(v[i,]) ) %*% Z[i,,] %*% as.matrix(w[i,])
    estimated[i,,] = as.numeric(d) * aux
  }
  
  return(estimated) 
}

###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################
###############################################################################################



table3 <- function(u_generative,v_generative,w_generative, c1_L1,c2_L1,c3_L1,c2,c3,c1_L1_unconstrained,c1_L2_unconstrained,c3_L1_unconstrained,c2_PMDL1 ,c3_PMDL1 ,Num_trials)
{
  
 # Num_trials = 100   ### number of MC simulations
  Num_data_sets = nrow(u_generative) 
  Num_penalties = 7
  sigma = c(1.25,1.5,1.75,2,2.25)  ##3 different parameters sigma
  distance_error = array(0, c(Num_penalties,Num_trials,length(sigma)))
   # sigma = 1
  
  ## cv_indicator
  cv_indicator = 0 
  ## if cv_indicator  = 0 then the parameters will only be estimated at the first iteration and used 
  ## with the same value there after
  ##  if cv_indicator = 1, the the code will estimate the parameters at every trial, this can take several days, not
  ## recommended, you might need parallel computing to gain speed
  

  for(s in 1:length(sigma))
  {
    print(s)
    
    for(iter in 1: Num_trials)
    {
     
      ## Generating data 
      print(iter)
      lizt <- list('mat1' =as.matrix(u_generative[2,]),'mat2' = as.matrix(v_generative[2,]),'mat3' = as.matrix(w_generative[2,]))
      aux =   array(1,c(1,1,1))
      aux = as.tensor(aux,drop= FALSE)
      true = ttl(aux, lizt, ms = c(1,2,3))
      
      dat =   Generate_data(u_generative[2,],v_generative[2,],w_generative[2,],sigma[s]) 
      X_observed =  dat$X_raw
      X_training = dat$X_training ### main signal
      X_locations = dat$X_locations 
      
      #################################################
      ## L1L1L1
      
      if(iter == 1 || cv_indicator == 1)
      {
        indexesL1L1L1_t1 = cv_PTD_L1L1L1(X_observed,X_training,X_locations,c1_L1_unconstrained,c2_L1_unconstrained,c3_L1_unconstrained)
        i  = indexesL1L1L1_t1$i  
        j  = indexesL1L1L1_t1$j
        k  = indexesL1L1L1_t1$k
        
        i_L1L1L1 = i
        j_L1L1L1 = j
        k_L1L1L1 = k
#         print("c1")
#         print(c1_L1_unconstrained[i])
#         print("c2")
#         print(c2_L1_unconstrained[j])
#         print("c3")
#         print(c3_L1_unconstrained[k])
      }
      
      PTDL1L1L1_t1 = PTD_L1L1L1(X_observed,c1_L1_unconstrained[i_L1L1L1],c2_L1_unconstrained[j_L1L1L1],c3_L1_unconstrained[k_L1L1L1],20)
      
      distance_error[1,iter,s] = tensor_distance(PTDL1L1L1_t1$d,PTDL1L1L1_t1$u,PTDL1L1L1_t1$v,PTDL1L1L1_t1$w,true) 

      print("L1L1L1")
      print(distance_error[1,iter,s])
      
      #################################################
      ## L1 FL FL   
      Av = fussed_lasso(length(v_generative[s,]))
      Aw = fussed_lasso(length(w_generative[s,]))
      kv = 0
      kw = 0
      
      if(iter == 1 || cv_indicator == 1)
      {
        indexesFLFL_t1 = cv_PTD_L1AB_unconstrained(X_observed,X_training,X_locations,Av,Aw,c1_L1,c2,c3,kv,kw)
        i1  = indexesFLFL_t1$i  
        j1  = indexesFLFL_t1$j
        k1 = indexesFLFL_t1$k
        
        i_L1FLFL = i1
        j_L1FLFL = j1
        k_L1FLFL = k1    
        
#         print("c1")
#         print(c1_L1[i1])
#         print("c2")
#         print(c2[j1])
#         print("c3")
#         print(c3[k1])
      }
      
       PTDFLFL_t1 = PTD_L1AB_unconstrained_2(X_observed,Av,Aw,c1_L1[i_L1FLFL],c2[j_L1FLFL ],c3[k_L1FLFL],20,kv,kw)
      distance_error[2,iter,s] = tensor_distance(PTDFLFL_t1 $d,PTDFLFL_t1 $u,PTDFLFL_t1 $v,PTDFLFL_t1$w,true)

      print("L1FLFLL")
      print(distance_error[2,iter,s])
      
      #################################################
      ## L1 TF FL
      Av = trend_filtering(1,length(v_generative[s,]))
      kv = 1
      
      if(iter == 1 || cv_indicator == 1)
      {
        indexesPTDTFFL_t1 = cv_PTD_L1AB_unconstrained(X_observed,X_training,X_locations,Av,Aw,c1_L1,c2,c3,kv,kw)
        i  = indexesPTDTFFL_t1$i  
        j  = indexesPTDTFFL_t1$j
        k = indexesPTDTFFL_t1$k
        
        i_L1TFFL = i
        j_L1TFFL = j
        k_L1TFFL = k  
        
#         print("c1")
#         print(c1_L1[i])
#         print("c2")
#         print(c2[j])
#         print("c3")
#         print(c3[k])
#         
      }
      
      
      PTDTFFL_t1 = PTD_L1AB_unconstrained_2(X_observed,Av,Aw,c1_L1[i_L1TFFL],c2[j_L1TFFL],c3[k_L1TFFL],20,kv,kw)
      
      distance_error[3,iter,s] = tensor_distance(PTDTFFL_t1$d,PTDTFFL_t1$u,PTDTFFL_t1$v,PTDTFFL_t1$w,true)
    
      # tensor_distance(aaa$d,aaa$u,aaa$v,aaa$w,true)
      
      print("L1FLTF")
      print(distance_error[3,iter,s])
      
      #################################################
      ## L1 TF TF     
      Av = trend_filtering(1,length(v_generative[s,]))
      Aw = trend_filtering(1,length(w_generative[s,]))
      kv = 1
      kw = 1
      
      
      if(iter == 1 || cv_indicator == 1)
      {
        indexesPTDTFTF_t1 = cv_PTD_L1AB_unconstrained(X_observed,X_training,X_locations,Av,Aw,c1_L1,c2,c3,kv,kw)
        i_L1TFTF  = indexesPTDTFTF_t1$i 
        j_L1TFTF   = indexesPTDTFTF_t1$j
        k_L1TFTF  = indexesPTDTFTF_t1$k
        
#         print("c1")
#         print(c1_L1[i_L1TFTF])
#         print("c2")
#         print(c2[j_L1TFTF])
#         print("c3")
#         print(c3[k_L1TFTF])
      }
       PTDTFTF_t1 = PTD_L1AB_unconstrained_2(X_observed,Av,Aw,c1_L1[i_L1TFTF ],c2[j_L1TFTF ],c3[k_L1TFTF ],20,kv,kw) 
      
      distance_error[4,iter,s] = tensor_distance(PTDTFTF_t1$d,PTDTFTF_t1$u,PTDTFTF_t1$v,PTDTFTF_t1$w,true)
   
      print("L1TFTF")
      print(distance_error[4,iter,s])
      
      #################################################
      ## PMD L1L1L1
      if(iter == 1 || cv_indicator == 1)
      {
        Z =  X_observed@data
        Z_training = X_training@data
        Z_locations = X_locations@data 
        dim = dim(X_observed)
        v_L1L1 =   matrix(0,dim[1],dim[2])
        w_L1L1 =   matrix(0,dim[1],dim[3])
        par_L1L1 =  matrix(0,dim[1],2)
        
        for( i in  1:dim(X_observed)[1])
        {
          out= cv_PMD_T_L1L1(Z[i,,],Z_training[i,,],Z_locations[i,,],c2_PMDL1,c3_PMDL1) 
          
          v_L1L1[i,] = as.vector(out$u)
          w_L1L1[i,] = as.vector(out$v)
          par_L1L1[i,1] = out$j
          par_L1L1[i,2] = out$k 
          
#           print("c2")
#           print(c2_PMDL1[par_L1L1[i,1]])
#           print("c3")
#           print(c3_PMDL1[par_L1L1[i,2]])
        }
      }
      
      estimatedPMDL1L1  = array(0, dim(Z)) 
      
     
      for( i in  1:dim(X_observed)[1])
      {
        #   out= cv_PMD_T_L1L1(Z[i,,],Z_training[i,,],Z_locations[i,,],c2_L1[par_L1L1[i,1]],c3_L1[par_L1L1[i,2]]) 
        
        out = PMD_L1L1(Z[i,,],c2_PMDL1[par_L1L1[i,1]],c3_PMDL1[par_L1L1[i,2]],20) 
        
        v_L1L1[i,] = as.vector(out$u)
        w_L1L1[i,] = as.vector(out$v)
        
        aux = as.matrix(v_L1L1[i,]) %*% t(as.matrix(w_L1L1[i,]))
        d = t( as.matrix(v_L1L1[i,]) ) %*% Z[i,,] %*% as.matrix(w_L1L1[i,])
        estimatedPMDL1L1[i,,] = as.numeric(d) * aux
      }
 
      
      distance_error[5,iter,s]  = fnorm(as.tensor(estimatedPMDL1L1,drop=FALSE)-true) 
  
      print("PMD_L1L1")
      print(distance_error[5,iter,s])
      
      
      #################################################
      ###  PMD FLFL
      if(iter == 1 || cv_indicator == 1)
      {
        v_FLFL =   matrix(0,dim[1],dim[2])
        w_FLFL =   matrix(0,dim[1],dim[3])
        par_FLFL =  matrix(0,dim[1],2)
        
        for( i in  1:dim(X_observed)[1])
        {
          out= cv_PMD_T_FLFL(Z[i,,],Z_training[i,,],Z_locations[i,,],c2,c3) 
          
          v_FLFL[i,] = as.vector(out$u)
          w_FLFL[i,] = as.vector(out$v)
          par_FLFL[i,1] = out$j
          par_FLFL[i,2] = out$k  
#           
#           print("c2")
#           print(c2[par_FLFL[i,1]])
#           print("c3")
#           print(c3[par_FLFL[i,2]])
        }
      }
      
      
      estimatedPMDFLFL  = array(0, dim(Z)) 
      
  
      for( i in  1:dim(X_observed)[1])
      {
        out=  PTD_FLFL(Z[i,,],c2[par_FLFL[i,1]],c3[par_FLFL[i,2]],Av,Aw,10) 
        
        v_FLFL[i,] = as.vector(out$u)
        w_FLFL[i,] = as.vector(out$v)
        
        aux = as.matrix(v_FLFL[i,]) %*% t(as.matrix(w_FLFL[i,]))
        d = t( as.matrix(v_FLFL[i,]) ) %*% Z[i,,] %*% as.matrix(w_FLFL[i,])
        estimatedPMDFLFL[i,,] = as.numeric(d) * aux
      }
  
      
      
      estimatedFLFL = as.tensor(estimatedPMDFLFL, drop = FALSE)
      distance_error[6,iter,s]  = fnorm(estimatedFLFL -true) 
      print("PMD_FLFL")
      print(distance_error[6,iter,s])
      
      
      #################################################
      ###   PMD FLL1
      if(iter == 1 || cv_indicator == 1)
      {
        v_FLL1 =   matrix(0,dim[1],dim[2])
        w_FLL1 =   matrix(0,dim[1],dim[3])
        par_FLL1 =  matrix(0,dim[1],2)
        
        for( i in  1:dim(X_observed)[1])
        {
          out= cv_PMD_T_FLL1(Z[i,,],Z_training[i,,],Z_locations[i,,],c2,c3_PMDL1) 
          
          v_FLL1[i,] = as.vector(out$u)
          w_FLL1[i,] = as.vector(out$v)
          par_FLL1[i,1] = out$j
          par_FLL1[i,2] = out$k   
          
#           print("c2")
#           print(c2[par_FLL1[i,1]])
#           print("c3")
#           print(c3_PMDL1[par_FLL1[i,2]])
        }
      }
      
      estimatedPMDFLL1  = array(0, dim(Z)) 

      for( i in  1:dim(X_observed)[1])
      {
        out= PMD_FLL1(Z[i,,],c2[par_FLL1[i,1]],c3_PMDL1[par_FLL1[i,2]],Av,10) 
        
        v_FLL1[i,] = as.vector(out$u)
        w_FLL1[i,] = as.vector(out$v)
        
        aux = as.matrix(v_FLL1[i,]) %*% t(as.matrix(w_FLL1[i,]))
        d = t( as.matrix(v_FLL1[i,]) ) %*% Z[i,,] %*% as.matrix(w_FLL1[i,])
        estimatedPMDFLL1[i,,] = as.numeric(d) * aux
      }
   
      estimatedFLL1 = as.tensor(estimatedPMDFLL1, drop = FALSE)
      distance_error[7,iter,s]  = fnorm(estimatedFLL1 -true) 
      
      print("PMD_FLL1")
      print(distance_error[7,iter,s])
    } # close for iter
  }## close for i 
  

  return(distance_error)
}

########################################################################
########################################################################
########################################################################
